import logoImg from "@/assets/docella-logo.png";
import { cn } from "@/lib/utils";

interface LogoProps {
  size?: number;
  withWordmark?: boolean;
  className?: string;
  wordmarkClassName?: string;
}

/** Marca Docella reutilizável: monograma + (opcional) wordmark */
export function Logo({ size = 36, withWordmark = true, className, wordmarkClassName }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <img
        src={logoImg}
        alt="Docella"
        width={size}
        height={size}
        loading="lazy"
        className="object-contain"
        style={{ width: size, height: size }}
      />
      {withWordmark && (
        <span className={cn("font-display text-lg font-bold tracking-tight", wordmarkClassName)}>
          Docella
        </span>
      )}
    </div>
  );
}
