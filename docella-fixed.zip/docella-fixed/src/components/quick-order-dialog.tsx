import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Zap } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

/**
 * Pedido em 10 segundos: cliente + produto + data + valor.
 * Cria cliente se não existir e cria pedido com 1 item.
 */
export function QuickOrderDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (b: boolean) => void }) {
  const { company } = useCompany();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [productName, setProductName] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [unitPrice, setUnitPrice] = useState(0);
  const [deliveryDate, setDeliveryDate] = useState("");
  const [recipeId, setRecipeId] = useState<string>("");

  const { data: recipes } = useQuery({
    queryKey: ["recipes-quick", company?.id], enabled: !!company && open,
    queryFn: async () => {
      const { data } = await supabase.from("recipes").select("id,name,suggested_price").eq("company_id", company!.id).eq("is_active", true).order("name");
      return data ?? [];
    },
  });

  const reset = () => {
    setCustomerName(""); setPhone(""); setProductName(""); setQuantity(1); setUnitPrice(0); setDeliveryDate(""); setRecipeId("");
  };

  const create = useMutation({
    mutationFn: async () => {
      if (!company) throw new Error("Empresa não carregada");
      if (!customerName.trim()) throw new Error("Informe o nome do cliente");
      if (!productName.trim()) throw new Error("Informe o produto");

      // 1. Buscar ou criar cliente (match por telefone se houver, senão por nome)
      let customerId: string | null = null;
      if (phone.trim()) {
        const { data: found } = await supabase
          .from("customers")
          .select("id")
          .eq("company_id", company.id)
          .eq("phone", phone.trim())
          .maybeSingle();
        customerId = found?.id ?? null;
      }
      if (!customerId) {
        const { data: created, error } = await supabase
          .from("customers")
          .insert({ company_id: company.id, name: customerName.trim(), phone: phone.trim() || null })
          .select("id").single();
        if (error) throw error;
        customerId = created.id;
      }

      // 2. Criar pedido
      const total = quantity * unitPrice;
      const { data: order, error: oerr } = await supabase
        .from("orders")
        .insert({
          company_id: company.id,
          customer_id: customerId,
          status: "confirmed",
          payment_status: "pending",
          delivery_date: deliveryDate || null,
          subtotal: total, total, source: "manual",
        } as any)
        .select("id").single();
      if (oerr) throw oerr;

      // 3. Item
      const { error: ierr } = await supabase.from("order_items").insert({
        order_id: order.id,
        recipe_id: recipeId || null,
        name: productName.trim(),
        quantity, unit_price: unitPrice, total,
      });
      if (ierr) throw ierr;

      return order.id;
    },
    onSuccess: (id) => {
      toast.success("Pedido criado! ✨");
      qc.invalidateQueries({ queryKey: ["orders"] });
      onOpenChange(false);
      reset();
      navigate({ to: "/app/orders/$id", params: { id } });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const onPickRecipe = (id: string) => {
    setRecipeId(id);
    const r = recipes?.find((x) => x.id === id);
    if (r) {
      setProductName(r.name);
      setUnitPrice(Number(r.suggested_price ?? 0));
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) reset(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <Zap className="h-5 w-5 text-accent" /> Pedido em 10 segundos
          </DialogTitle>
          <DialogDescription>Cliente, produto, data e valor. Pronto.</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Nome do cliente</Label>
              <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Maria" autoFocus />
            </div>
            <div>
              <Label>WhatsApp</Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(11) 99999-0000" />
            </div>
          </div>

          {recipes && recipes.length > 0 && (
            <div>
              <Label className="text-xs text-muted-foreground">Receita salva (opcional)</Label>
              <select value={recipeId} onChange={(e) => onPickRecipe(e.target.value)} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
                <option value="">— Digitar manualmente —</option>
                {recipes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </div>
          )}

          <div>
            <Label>Produto</Label>
            <Input value={productName} onChange={(e) => setProductName(e.target.value)} placeholder="Bolo de chocolate" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>Qtd</Label>
              <Input type="number" min="1" value={quantity} onChange={(e) => setQuantity(Number(e.target.value) || 1)} />
            </div>
            <div>
              <Label>Valor unit. (R$)</Label>
              <Input type="number" step="0.01" value={unitPrice} onChange={(e) => setUnitPrice(Number(e.target.value) || 0)} />
            </div>
            <div>
              <Label>Entrega</Label>
              <Input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} />
            </div>
          </div>

          <div className="rounded-lg bg-secondary/60 px-3 py-2 text-sm flex items-center justify-between">
            <span className="text-muted-foreground">Total</span>
            <strong className="font-display text-lg text-primary">
              {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(quantity * unitPrice)}
            </strong>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button className="gradient-primary border-0 text-primary-foreground" onClick={() => create.mutate()} disabled={create.isPending}>
            {create.isPending ? "Criando..." : "Criar pedido"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
