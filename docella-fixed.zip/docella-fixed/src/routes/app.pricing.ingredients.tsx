import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Wheat } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { formatBRL, formatNumber } from "@/lib/format";
import { costPerUnit } from "@/lib/pricing";

export const Route = createFileRoute("/app/pricing/ingredients")({
  component: IngredientsPage,
});

interface Ingredient {
  id: string;
  name: string;
  unit: string;
  package_size: number;
  package_cost: number;
  supplier: string | null;
}

function IngredientsPage() {
  const { company } = useCompany();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Ingredient | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["ingredients", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ingredients")
        .select("*")
        .eq("company_id", company!.id)
        .order("name");
      if (error) throw error;
      return (data ?? []) as Ingredient[];
    },
  });

  const removeMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("ingredients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Ingrediente removido");
      qc.invalidateQueries({ queryKey: ["ingredients"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const openNew = () => { setEditing(null); setOpen(true); };
  const openEdit = (ing: Ingredient) => { setEditing(ing); setOpen(true); };

  return (
    <>
      <PageHeader
        title="Ingredientes"
        description="Cadastre o que você usa para que os custos sejam calculados automaticamente."
        actions={<Button onClick={openNew} className="gradient-primary border-0 text-primary-foreground"><Plus className="h-4 w-4" /> Novo ingrediente</Button>}
      />

      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 rounded-xl border bg-card animate-pulse" />)}</div>
      ) : !data || data.length === 0 ? (
        <EmptyState icon={Wheat} title="Nenhum ingrediente" description="Adicione farinha, açúcar, manteiga..." action={{ label: "Adicionar ingrediente", onClick: openNew }} />
      ) : (
        <div className="overflow-hidden rounded-2xl border bg-card shadow-soft">
          <div className="grid grid-cols-12 gap-3 border-b bg-muted/40 px-4 py-2.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <div className="col-span-5">Nome</div>
            <div className="col-span-2">Embalagem</div>
            <div className="col-span-2 text-right">Custo</div>
            <div className="col-span-2 text-right">Custo/un</div>
            <div className="col-span-1" />
          </div>
          {data.map((ing) => (
            <div key={ing.id} className="grid grid-cols-12 items-center gap-3 border-b px-4 py-3 text-sm last:border-0 hover:bg-muted/20">
              <div className="col-span-5">
                <div className="font-medium">{ing.name}</div>
                {ing.supplier && <div className="text-xs text-muted-foreground">{ing.supplier}</div>}
              </div>
              <div className="col-span-2 text-muted-foreground">{formatNumber(ing.package_size, 0)} {ing.unit}</div>
              <div className="col-span-2 text-right">{formatBRL(ing.package_cost)}</div>
              <div className="col-span-2 text-right tabular-nums">{formatBRL(costPerUnit(ing))}/{ing.unit}</div>
              <div className="col-span-1 flex justify-end gap-1">
                <Button size="icon" variant="ghost" onClick={() => openEdit(ing)}><Pencil className="h-3.5 w-3.5" /></Button>
                <Button size="icon" variant="ghost" onClick={() => { if (confirm(`Remover ${ing.name}?`)) removeMut.mutate(ing.id); }}><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <IngredientDialog open={open} onOpenChange={setOpen} editing={editing} companyId={company?.id} />
    </>
  );
}

function IngredientDialog({ open, onOpenChange, editing, companyId }: { open: boolean; onOpenChange: (b: boolean) => void; editing: Ingredient | null; companyId?: string }) {
  const qc = useQueryClient();
  const [name, setName] = useState(editing?.name ?? "");
  const [unit, setUnit] = useState(editing?.unit ?? "g");
  const [packageSize, setPackageSize] = useState<number>(editing?.package_size ?? 1000);
  const [packageCost, setPackageCost] = useState<number>(editing?.package_cost ?? 0);
  const [supplier, setSupplier] = useState(editing?.supplier ?? "");

  // sync when editing changes
  useState(() => null);
  if (open && editing && name !== editing.name) {
    setName(editing.name); setUnit(editing.unit); setPackageSize(editing.package_size); setPackageCost(editing.package_cost); setSupplier(editing.supplier ?? "");
  }
  if (open && !editing && name && (packageSize !== 1000 || unit !== "g") === false) { /* no-op */ }

  const save = useMutation({
    mutationFn: async () => {
      if (!companyId) throw new Error("Empresa não carregada");
      if (!name.trim()) throw new Error("Informe o nome");
      const payload = { name: name.trim(), unit, package_size: Number(packageSize) || 0, package_cost: Number(packageCost) || 0, supplier: supplier.trim() || null, company_id: companyId };
      if (editing) {
        const { error } = await supabase.from("ingredients").update(payload).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("ingredients").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(editing ? "Ingrediente atualizado" : "Ingrediente criado");
      qc.invalidateQueries({ queryKey: ["ingredients"] });
      onOpenChange(false);
      setName(""); setUnit("g"); setPackageSize(1000); setPackageCost(0); setSupplier("");
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) { setName(""); setUnit("g"); setPackageSize(1000); setPackageCost(0); setSupplier(""); } }}>
      <DialogContent>
        <DialogHeader><DialogTitle>{editing ? "Editar ingrediente" : "Novo ingrediente"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Farinha de trigo" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Unidade</Label>
              <select value={unit} onChange={(e) => setUnit(e.target.value)} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                <option value="g">grama (g)</option>
                <option value="kg">quilo (kg)</option>
                <option value="ml">mililitro (ml)</option>
                <option value="l">litro (l)</option>
                <option value="un">unidade (un)</option>
              </select>
            </div>
            <div><Label>Tamanho da embalagem</Label><Input type="number" step="any" value={packageSize} onChange={(e) => setPackageSize(Number(e.target.value))} /></div>
          </div>
          <div><Label>Custo da embalagem (R$)</Label><Input type="number" step="0.01" value={packageCost} onChange={(e) => setPackageCost(Number(e.target.value))} /></div>
          <div><Label>Fornecedor (opcional)</Label><Input value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="Atacadão, Supermercado X..." /></div>
          {Number(packageSize) > 0 && Number(packageCost) > 0 && (
            <div className="rounded-lg bg-secondary/60 px-3 py-2 text-xs">
              Custo por {unit}: <strong className="text-foreground">{formatBRL(packageCost / packageSize)}</strong>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button className="gradient-primary border-0 text-primary-foreground" onClick={() => save.mutate()} disabled={save.isPending}>
            {save.isPending ? "Salvando..." : "Salvar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
