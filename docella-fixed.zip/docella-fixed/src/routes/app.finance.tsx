import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/page-header";
import { formatBRL } from "@/lib/format";
import { TrendingUp, DollarSign, ShoppingBag, Receipt } from "lucide-react";

export const Route = createFileRoute("/app/finance")({
  component: FinancePage,
});

function FinancePage() {
  const { company } = useCompany();
  const [period, setPeriod] = useState<"30" | "90" | "365">("30");

  const since = useMemo(() => { const d = new Date(); d.setDate(d.getDate() - Number(period)); return d.toISOString(); }, [period]);

  const { data } = useQuery({
    queryKey: ["finance", company?.id, period],
    enabled: !!company,
    queryFn: async () => {
      const [{ data: orders }, { data: payments }] = await Promise.all([
        supabase.from("orders").select("id,total,status,created_at").eq("company_id", company!.id).gte("created_at", since),
        supabase.from("payments").select("amount,paid_at,order_id,orders!inner(company_id)").eq("orders.company_id", company!.id).gte("paid_at", since),
      ]);
      return { orders: orders ?? [], payments: payments ?? [] };
    },
  });

  const stats = useMemo(() => {
    const validOrders = (data?.orders ?? []).filter((o: any) => o.status !== "canceled");
    const revenue = validOrders.reduce((s: number, o: any) => s + Number(o.total), 0);
    const received = (data?.payments ?? []).reduce((s: number, p: any) => s + Number(p.amount), 0);
    const ticket = validOrders.length > 0 ? revenue / validOrders.length : 0;
    return { revenue, received, ticket, count: validOrders.length, pending: revenue - received };
  }, [data]);

  // Daily series
  const series = useMemo(() => {
    const map = new Map<string, number>();
    (data?.orders ?? []).filter((o: any) => o.status !== "canceled").forEach((o: any) => {
      const day = o.created_at.slice(0, 10);
      map.set(day, (map.get(day) ?? 0) + Number(o.total));
    });
    const sorted = Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
    const max = Math.max(1, ...sorted.map(([, v]) => v));
    return { sorted, max };
  }, [data]);

  return (
    <div className="px-6 py-8 lg:px-10">
      <PageHeader
        title="Financeiro"
        description="Acompanhe seu faturamento, recebimentos e o que ainda está a receber."
        actions={
          <div className="flex gap-1 rounded-xl border bg-card p-1 shadow-soft">
            {[{v:"30",l:"30 dias"},{v:"90",l:"3 meses"},{v:"365",l:"12 meses"}].map((p) => (
              <button key={p.v} onClick={() => setPeriod(p.v as any)} className={`rounded-lg px-3 py-1 text-xs font-medium transition ${period === p.v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{p.l}</button>
            ))}
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={TrendingUp} label="Faturamento" value={formatBRL(stats.revenue)} />
        <Stat icon={DollarSign} label="Recebido" value={formatBRL(stats.received)} accent="success" />
        <Stat icon={Receipt} label="A receber" value={formatBRL(stats.pending)} accent="warning" />
        <Stat icon={ShoppingBag} label="Ticket médio" value={formatBRL(stats.ticket)} hint={`${stats.count} pedidos`} />
      </div>

      <div className="mt-6 rounded-2xl border bg-card p-6 shadow-soft">
        <h2 className="font-display text-lg font-bold">Faturamento ao longo do tempo</h2>
        {series.sorted.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">Sem dados no período.</p>
        ) : (
          <div className="mt-6 flex h-48 items-end gap-1.5">
            {series.sorted.map(([day, val]) => (
              <div key={day} className="group relative flex-1">
                <div className="rounded-t-md gradient-primary transition" style={{ height: `${(val / series.max) * 100}%`, minHeight: 2 }} />
                <div className="absolute -top-9 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded-md bg-popover px-2 py-1 text-xs shadow-elegant group-hover:block">
                  {day.split("-").reverse().join("/")} · {formatBRL(val)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, hint, accent }: { icon: any; label: string; value: string; hint?: string; accent?: "success" | "warning" }) {
  const colors = accent === "success" ? "text-success" : accent === "warning" ? "text-warning-foreground" : "text-foreground";
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft transition hover:shadow-elegant">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</span>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className={`mt-3 font-display text-2xl font-bold tabular-nums ${colors}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}
