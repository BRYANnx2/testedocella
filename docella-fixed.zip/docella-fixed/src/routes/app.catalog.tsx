import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import {
  BookOpen, Copy, ExternalLink, Image as ImageIcon, Eye,
  EyeOff, Utensils, Link2
} from "lucide-react";
import { formatBRL } from "@/lib/format";

export const Route = createFileRoute("/app/catalog")({
  component: CatalogPage,
});

interface Recipe {
  id: string;
  name: string;
  description: string | null;
  public_description: string | null;
  cover_url: string | null;
  servings: number;
  suggested_price: number | null;
  price_override: number | null;
  is_active: boolean;
  show_in_catalog: boolean;
}

function CatalogPage() {
  const { company, refetch: refetchCompany } = useCompany();
  const qc = useQueryClient();

  // Catalog settings state
  const [headline, setHeadline] = useState(company?.catalog_headline ?? "");
  const [description, setDescription] = useState(company?.catalog_description ?? "");
  const [waPhone, setWaPhone] = useState(company?.whatsapp_phone ?? "");

  const publicUrl = company?.slug
    ? `${window.location.origin}/c/${company.slug}`
    : null;

  // Sync if company loads after render
  if (company && headline === "" && company.catalog_headline) setHeadline(company.catalog_headline);
  if (company && description === "" && company.catalog_description) setDescription(company.catalog_description);
  if (company && waPhone === "" && company.whatsapp_phone) setWaPhone(company.whatsapp_phone);

  const { data: recipes, isLoading } = useQuery({
    queryKey: ["recipes-catalog", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("recipes")
        .select("id,name,description,public_description,cover_url,servings,suggested_price,price_override,is_active,show_in_catalog")
        .eq("company_id", company!.id)
        .order("name");
      if (error) throw error;
      return (data ?? []) as Recipe[];
    },
  });

  const saveSettings = useMutation({
    mutationFn: async () => {
      if (!company) return;
      const { error } = await supabase
        .from("companies")
        .update({
          catalog_headline: headline.trim() || null,
          catalog_description: description.trim() || null,
          whatsapp_phone: waPhone.trim() || null,
        })
        .eq("id", company.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Configurações do cardápio salvas!");
      refetchCompany();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const toggleCatalog = useMutation({
    mutationFn: async ({ id, show_in_catalog }: { id: string; show_in_catalog: boolean }) => {
      const { error } = await supabase
        .from("recipes")
        .update({ show_in_catalog })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["recipes-catalog"] });
      toast.success("Visibilidade atualizada");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("recipes")
        .update({ is_active })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["recipes-catalog"] });
      toast.success("Status atualizado");
    },
    onError: (e: any) => toast.error(e.message),
  });

  function copyLink() {
    if (!publicUrl) return;
    navigator.clipboard.writeText(publicUrl);
    toast.success("Link copiado!");
  }

  const visibleCount = (recipes ?? []).filter((r) => r.show_in_catalog && r.is_active).length;

  return (
    <div className="px-6 py-8 lg:px-10 max-w-4xl">
      <PageHeader
        title="Cardápio Digital"
        description="Configure seu cardápio público e compartilhe com seus clientes."
      />

      {/* Link de compartilhamento */}
      {publicUrl ? (
        <div className="mb-6 rounded-2xl border bg-card p-5 shadow-soft">
          <div className="flex items-center gap-2 mb-3">
            <Link2 className="h-4 w-4 text-primary" />
            <h2 className="font-display text-base font-bold">Seu link público</h2>
            <span className="ml-auto text-xs text-muted-foreground">
              {visibleCount} produto{visibleCount !== 1 ? "s" : ""} visível{visibleCount !== 1 ? "is" : ""}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 rounded-lg bg-secondary/60 px-3 py-2 text-xs font-mono truncate">
              {publicUrl}
            </code>
            <Button size="sm" variant="outline" onClick={copyLink}>
              <Copy className="h-3.5 w-3.5" />
            </Button>
            <Button size="sm" variant="outline" asChild>
              <a href={publicUrl} target="_blank" rel="noreferrer">
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Compartilhe esse link no Instagram, WhatsApp ou Stories. Seus clientes podem montar o pedido direto por aqui.
          </p>
        </div>
      ) : (
        <div className="mb-6 rounded-2xl border bg-secondary/40 p-5">
          <p className="text-sm text-muted-foreground">
            Aguardando configuração do slug da empresa. Salve as configurações abaixo para ativar o link público.
          </p>
        </div>
      )}

      {/* Configurações do cardápio */}
      <div className="mb-6 rounded-2xl border bg-card p-5 shadow-soft">
        <h2 className="font-display text-base font-bold mb-4 flex items-center gap-2">
          <BookOpen className="h-4 w-4" />
          Personalizar cardápio
        </h2>
        <div className="space-y-4">
          <div>
            <Label>Título do cardápio</Label>
            <Input
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              placeholder="Ex: Doces artesanais feitos com amor 🍰"
            />
            <p className="mt-1 text-xs text-muted-foreground">Aparece abaixo do nome da sua confeitaria no cardápio público.</p>
          </div>
          <div>
            <Label>Descrição / bio</Label>
            <Textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Conte um pouco sobre sua confeitaria, especialidades, localização..."
            />
          </div>
          <div>
            <Label>WhatsApp da confeitaria</Label>
            <Input
              value={waPhone}
              onChange={(e) => setWaPhone(e.target.value)}
              placeholder="(11) 99999-0000"
            />
            <p className="mt-1 text-xs text-muted-foreground">
              Usado para redirecionar clientes que clicam no ícone de mensagem. Inclua DDD.
            </p>
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <Button
            className="gradient-primary border-0 text-primary-foreground"
            onClick={() => saveSettings.mutate()}
            disabled={saveSettings.isPending}
          >
            {saveSettings.isPending ? "Salvando..." : "Salvar configurações"}
          </Button>
        </div>
      </div>

      {/* Produtos no cardápio */}
      <div className="rounded-2xl border bg-card p-5 shadow-soft">
        <h2 className="font-display text-base font-bold mb-1 flex items-center gap-2">
          <Utensils className="h-4 w-4" />
          Produtos no cardápio
        </h2>
        <p className="text-xs text-muted-foreground mb-4">
          Ative ou desative cada produto individualmente. Produtos com "Mostrar no cardápio" ligado e preço definido aparecem para seus clientes.
        </p>

        {isLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-16 rounded-xl border bg-secondary/40 animate-pulse" />
            ))}
          </div>
        ) : (recipes ?? []).length === 0 ? (
          <EmptyState
            icon={Utensils}
            title="Nenhuma receita cadastrada"
            description="Vá em Precificação e cadastre suas receitas para exibi-las no cardápio."
          />
        ) : (
          <div className="divide-y">
            {(recipes ?? []).map((r) => {
              const price = Number(r.price_override ?? r.suggested_price ?? 0);
              const hasPrice = price > 0;
              return (
                <div key={r.id} className="flex items-center gap-3 py-3">
                  {/* Cover thumb */}
                  <div className="h-12 w-12 flex-shrink-0 rounded-lg overflow-hidden bg-secondary/50 flex items-center justify-center">
                    {r.cover_url ? (
                      <img src={r.cover_url} alt={r.name} className="h-full w-full object-cover" />
                    ) : (
                      <ImageIcon className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{r.name}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      {hasPrice ? (
                        <span className="text-xs font-semibold text-primary">{formatBRL(price)}</span>
                      ) : (
                        <span className="text-xs text-warning font-medium">⚠ Sem preço</span>
                      )}
                      {r.public_description && (
                        <span className="text-xs text-muted-foreground truncate max-w-[160px]">{r.public_description}</span>
                      )}
                    </div>
                  </div>

                  {/* Ativo */}
                  <div className="flex flex-col items-center gap-0.5">
                    <span className="text-[10px] text-muted-foreground">Ativo</span>
                    <Switch
                      checked={r.is_active}
                      onCheckedChange={(v) => toggleActive.mutate({ id: r.id, is_active: v })}
                    />
                  </div>

                  {/* Cardápio */}
                  <div className="flex flex-col items-center gap-0.5">
                    <span className="text-[10px] text-muted-foreground">Cardápio</span>
                    <Switch
                      checked={r.show_in_catalog}
                      onCheckedChange={(v) => toggleCatalog.mutate({ id: r.id, show_in_catalog: v })}
                      disabled={!hasPrice}
                    />
                  </div>

                  {/* Status visual */}
                  <div className="flex-shrink-0">
                    {r.show_in_catalog && r.is_active && hasPrice ? (
                      <Eye className="h-4 w-4 text-success" title="Visível no cardápio" />
                    ) : (
                      <EyeOff className="h-4 w-4 text-muted-foreground/50" title="Não aparece no cardápio" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
