import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useAuth } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Sparkles, CreditCard, Smartphone, Copy, ExternalLink, RefreshCw, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { formatBRL } from "@/lib/format";
import { createSubscriptionCharge, refreshChargeStatus } from "@/server/billing.functions";

export const Route = createFileRoute("/app/billing")({
  component: BillingPage,
});

const PLANS = [
  { id: "pro" as const, name: "Pro", price: 49.9, features: ["Receitas ilimitadas", "Pedidos ilimitados", "Catálogo público", "WhatsApp templates", "Suporte prioritário"] },
  { id: "premium" as const, name: "Premium", price: 99.9, features: ["Tudo do Pro", "Multi-usuário", "Relatórios avançados", "API exclusiva", "Onboarding guiado"], highlight: true },
];

function BillingPage() {
  const { company } = useCompany();
  const { user } = useAuth();
  const createCharge = useServerFn(createSubscriptionCharge);
  const refreshCharge = useServerFn(refreshChargeStatus);

  const [plan, setPlan] = useState<"pro" | "premium">("pro");
  const [billingType, setBillingType] = useState<"PIX" | "CREDIT_CARD" | "BOLETO">("PIX");
  const [cpfCnpj, setCpfCnpj] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const { data: charges, refetch } = useQuery({
    queryKey: ["billing-charges", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data } = await supabase.from("billing_charges" as any).select("*").eq("company_id", company!.id).order("created_at", { ascending: false }).limit(10);
      return data ?? [];
    },
  });

  const { data: subscription } = useQuery({
    queryKey: ["subscription", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data } = await supabase.from("subscriptions").select("*").eq("company_id", company!.id).maybeSingle();
      return data;
    },
  });

  async function handleCheckout() {
    if (!company || !user) return;
    if (cpfCnpj.replace(/\D/g, "").length < 11) { toast.error("Informe um CPF/CNPJ válido."); return; }
    setLoading(true);
    try {
      const res = await createCharge({
        data: {
          companyId: company.id,
          plan,
          billingType,
          cpfCnpj,
          customerName: company.name,
          customerEmail: user.email!,
          mobilePhone: phone || undefined,
        },
      });
      setResult(res);
      toast.success("Cobrança gerada! Pague para ativar o plano.");
      refetch();
    } catch (e: any) {
      toast.error(e.message ?? "Erro ao gerar cobrança");
    } finally {
      setLoading(false);
    }
  }

  async function handleRefresh(chargeId: string) {
    if (!company) return;
    try {
      const r = await refreshCharge({ data: { chargeId, companyId: company.id } });
      if (r.paid) toast.success("Pagamento confirmado! Plano ativo 🎉");
      else toast.info(`Status atual: ${r.status}`);
      refetch();
    } catch (e: any) { toast.error(e.message); }
  }

  const isActive = subscription?.status === "active";

  return (
    <div className="p-6 lg:p-10">
      <PageHeader title="Assinatura" description="Ative seu plano via PIX, cartão ou boleto através do Asaas." />

      {isActive && (
        <Card className="mb-6 border-success/30 bg-success/5 p-4">
          <div className="flex items-center gap-2 text-success">
            <CheckCircle2 className="h-5 w-5" />
            <strong>Plano {subscription?.plan} ativo</strong>
            <span className="text-muted-foreground">· renova em {subscription?.current_period_end ? new Date(subscription.current_period_end).toLocaleDateString("pt-BR") : "—"}</span>
          </div>
        </Card>
      )}

      {/* Planos */}
      <div className="mb-8 grid gap-4 md:grid-cols-2">
        {PLANS.map((p) => (
          <Card key={p.id} className={`p-6 cursor-pointer transition ${plan === p.id ? "border-primary shadow-elegant" : ""} ${p.highlight ? "bg-gradient-to-br from-primary/5 to-accent/5" : ""}`} onClick={() => setPlan(p.id)}>
            <div className="flex items-center justify-between">
              <h3 className="font-display text-xl font-bold">{p.name}</h3>
              {p.highlight && <Badge className="bg-accent text-accent-foreground">Recomendado</Badge>}
            </div>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="font-display text-3xl font-bold text-primary">{formatBRL(p.price)}</span>
              <span className="text-sm text-muted-foreground">/mês</span>
            </div>
            <ul className="mt-4 space-y-1.5 text-sm">
              {p.features.map((f) => (
                <li key={f} className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-success" /> {f}</li>
              ))}
            </ul>
          </Card>
        ))}
      </div>

      {/* Checkout form */}
      <Card className="p-6">
        <h3 className="font-display text-lg font-bold flex items-center gap-2"><Sparkles className="h-4 w-4 text-accent" /> Finalizar assinatura — {PLANS.find(x => x.id === plan)?.name}</h3>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <Label>CPF/CNPJ</Label>
            <Input value={cpfCnpj} onChange={(e) => setCpfCnpj(e.target.value)} placeholder="000.000.000-00" />
          </div>
          <div>
            <Label>Celular (opcional)</Label>
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(11) 90000-0000" />
          </div>
        </div>

        <div className="mt-4">
          <Label>Método de pagamento</Label>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {([
              { v: "PIX", icon: Smartphone, label: "PIX" },
              { v: "CREDIT_CARD", icon: CreditCard, label: "Cartão" },
              { v: "BOLETO", icon: ExternalLink, label: "Boleto" },
            ] as const).map((opt) => (
              <button key={opt.v} type="button" onClick={() => setBillingType(opt.v)} className={`flex items-center justify-center gap-2 rounded-lg border p-3 text-sm transition ${billingType === opt.v ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted/50"}`}>
                <opt.icon className="h-4 w-4" /> {opt.label}
              </button>
            ))}
          </div>
        </div>

        <Button className="mt-6 w-full gradient-primary border-0 text-primary-foreground" onClick={handleCheckout} disabled={loading}>
          {loading ? "Gerando cobrança..." : `Pagar ${formatBRL(PLANS.find(x => x.id === plan)!.price)}`}
        </Button>
      </Card>

      {/* Result */}
      {result && (
        <Card className="mt-6 p-6">
          <h4 className="font-display text-lg font-bold">Cobrança gerada ✨</h4>
          {result.pixQrcode ? (
            <div className="mt-4 flex flex-col items-center gap-3">
              <img src={`data:image/png;base64,${result.pixQrcode}`} alt="QR PIX" className="h-56 w-56 rounded-lg border" />
              <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(result.pixCopyPaste); toast.success("Código PIX copiado!"); }}>
                <Copy className="h-3.5 w-3.5" /> Copiar PIX copia-e-cola
              </Button>
            </div>
          ) : null}
          {result.invoiceUrl && (
            <a href={result.invoiceUrl} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-sm text-primary hover:underline">
              Abrir fatura completa <ExternalLink className="h-3 w-3" />
            </a>
          )}
          <Button variant="outline" size="sm" className="mt-4" onClick={() => handleRefresh(result.chargeId)}>
            <RefreshCw className="h-3.5 w-3.5" /> Já paguei, verificar status
          </Button>
        </Card>
      )}

      {/* History */}
      {charges && charges.length > 0 && (
        <div className="mt-8">
          <h3 className="font-display text-lg font-bold mb-3">Histórico</h3>
          <Card className="divide-y overflow-hidden">
            {charges.map((c: any) => (
              <div key={c.id} className="flex items-center justify-between gap-3 p-3 text-sm">
                <div>
                  <div className="font-medium">{c.description}</div>
                  <div className="text-xs text-muted-foreground">{new Date(c.created_at).toLocaleString("pt-BR")} · {c.billing_type}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={c.status === "RECEIVED" || c.status === "CONFIRMED" ? "default" : "secondary"}>{c.status}</Badge>
                  <span className="font-semibold">{formatBRL(Number(c.amount))}</span>
                  <Button size="icon" variant="ghost" onClick={() => handleRefresh(c.asaas_charge_id)}><RefreshCw className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            ))}
          </Card>
        </div>
      )}
    </div>
  );
}
