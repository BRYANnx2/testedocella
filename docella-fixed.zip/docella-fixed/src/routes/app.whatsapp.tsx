import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/page-header";
import { MessageCircle } from "lucide-react";

export const Route = createFileRoute("/app/whatsapp")({
  component: WhatsAppPage,
});

const TRIGGER_LABELS: Record<string, string> = {
  quote: "Envio de orçamento",
  confirmation: "Confirmação de pedido",
  payment_reminder: "Lembrete de pagamento",
  delivery_reminder: "Lembrete de entrega",
  review_request: "Pedido de avaliação",
};

function WhatsAppPage() {
  const { company } = useCompany();
  const qc = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const { data, isLoading } = useQuery({
    queryKey: ["wa-templates", company?.id], enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase.from("whatsapp_templates").select("*").eq("company_id", company!.id).order("trigger");
      if (error) throw error;
      return data ?? [];
    },
  });

  const update = useMutation({
    mutationFn: async ({ id, body }: { id: string; body: string }) => {
      const { error } = await supabase.from("whatsapp_templates").update({ body }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Template salvo"); qc.invalidateQueries({ queryKey: ["wa-templates"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="px-6 py-8 lg:px-10">
      <PageHeader
        title="Mensagens do WhatsApp"
        description="Personalize as mensagens que você envia em cada momento do pedido. Use {cliente}, {total}, {data}, {detalhes}, {sinal}, {saldo}, {endereco}."
      />

      <div className="rounded-2xl border bg-secondary/40 p-4 mb-6 flex gap-3 items-start">
        <MessageCircle className="h-5 w-5 text-success mt-0.5 flex-shrink-0" />
        <div className="text-sm">
          <strong>Como funciona:</strong> ao enviar uma mensagem dentro de um pedido, abrimos o WhatsApp Web/App com o texto pronto, já com os dados do cliente e do pedido.
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-32 rounded-xl border bg-card animate-pulse" />)}</div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {(data ?? []).map((t: any) => {
            const value = drafts[t.id] ?? t.body;
            return (
              <div key={t.id} className="rounded-2xl border bg-card p-5 shadow-soft">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="font-display text-base font-bold">{TRIGGER_LABELS[t.trigger] ?? t.name}</h3>
                </div>
                <Label className="text-xs">Mensagem</Label>
                <Textarea rows={5} value={value} onChange={(e) => setDrafts({ ...drafts, [t.id]: e.target.value })} />
                <div className="mt-3 flex justify-end">
                  <Button size="sm" onClick={() => update.mutate({ id: t.id, body: value })} disabled={update.isPending || value === t.body}>Salvar</Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
