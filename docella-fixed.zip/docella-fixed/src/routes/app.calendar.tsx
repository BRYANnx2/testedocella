import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/page-header";
import { formatBRL } from "@/lib/format";

export const Route = createFileRoute("/app/calendar")({
  component: CalendarPage,
});

function CalendarPage() {
  const { company } = useCompany();
  const [cursor, setCursor] = useState(() => { const d = new Date(); d.setDate(1); d.setHours(0,0,0,0); return d; });

  const start = new Date(cursor); start.setDate(1);
  const end = new Date(cursor); end.setMonth(end.getMonth() + 1); end.setDate(0);

  const { data } = useQuery({
    queryKey: ["calendar", company?.id, cursor.toISOString()],
    enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("id,order_number,total,status,delivery_date,customers(name)")
        .eq("company_id", company!.id)
        .gte("delivery_date", start.toISOString().slice(0, 10))
        .lte("delivery_date", end.toISOString().slice(0, 10))
        .neq("status", "canceled")
        .order("delivery_date");
      if (error) throw error;
      return data ?? [];
    },
  });

  const ordersByDay = useMemo(() => {
    const map = new Map<string, any[]>();
    (data ?? []).forEach((o: any) => {
      if (!o.delivery_date) return;
      const arr = map.get(o.delivery_date) ?? [];
      arr.push(o);
      map.set(o.delivery_date, arr);
    });
    return map;
  }, [data]);

  // Build month grid
  const firstWeekday = start.getDay();
  const daysInMonth = end.getDate();
  const cells: (Date | null)[] = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(cursor.getFullYear(), cursor.getMonth(), d));
  while (cells.length % 7 !== 0) cells.push(null);

  const monthLabel = cursor.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  const today = new Date(); today.setHours(0,0,0,0);

  return (
    <div className="px-6 py-8 lg:px-10">
      <PageHeader
        title="Calendário"
        description="Visão clara dos pedidos por data de entrega."
        actions={
          <div className="flex items-center gap-1">
            <Button size="icon" variant="outline" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}><ChevronLeft className="h-4 w-4" /></Button>
            <div className="min-w-[160px] text-center font-display text-base font-semibold capitalize">{monthLabel}</div>
            <Button size="icon" variant="outline" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}><ChevronRight className="h-4 w-4" /></Button>
          </div>
        }
      />

      <div className="overflow-hidden rounded-2xl border bg-card shadow-soft">
        <div className="grid grid-cols-7 border-b bg-muted/40 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((d) => <div key={d} className="px-3 py-2 text-center">{d}</div>)}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((d, i) => {
            const key = d ? d.toISOString().slice(0, 10) : null;
            const orders = key ? ordersByDay.get(key) ?? [] : [];
            const isToday = d && d.getTime() === today.getTime();
            return (
              <div key={i} className={`min-h-[110px] border-b border-r p-2 ${!d ? "bg-muted/20" : ""}`}>
                {d && (
                  <>
                    <div className={`mb-1 inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-medium ${isToday ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{d.getDate()}</div>
                    <div className="space-y-1">
                      {orders.slice(0, 3).map((o: any) => (
                        <Link key={o.id} to="/app/orders/$id" params={{ id: o.id }} className="block truncate rounded-md bg-secondary/70 px-1.5 py-0.5 text-[11px] font-medium hover:bg-secondary">
                          #{o.order_number} {o.customers?.name ?? ""}
                        </Link>
                      ))}
                      {orders.length > 3 && <div className="text-[11px] text-muted-foreground">+{orders.length - 3} mais</div>}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border bg-card p-4 shadow-soft">
          <div className="text-xs text-muted-foreground">Pedidos no mês</div>
          <div className="mt-1 font-display text-2xl font-bold">{(data ?? []).length}</div>
        </div>
        <div className="rounded-2xl border bg-card p-4 shadow-soft">
          <div className="text-xs text-muted-foreground">Faturamento previsto</div>
          <div className="mt-1 font-display text-2xl font-bold text-primary">{formatBRL((data ?? []).reduce((s: number, o: any) => s + Number(o.total), 0))}</div>
        </div>
        <div className="rounded-2xl border bg-card p-4 shadow-soft">
          <div className="text-xs text-muted-foreground">Próxima entrega</div>
          <div className="mt-1 font-display text-2xl font-bold">{(data ?? [])[0]?.delivery_date?.split("-").reverse().join("/") ?? "—"}</div>
        </div>
      </div>
    </div>
  );
}
