import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useAuth } from "@/lib/auth-context";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/page-header";
import { ExternalLink } from "lucide-react";

export const Route = createFileRoute("/app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const { company, refetch } = useCompany();
  const { user, signOut } = useAuth();
  const qc = useQueryClient();

  const [name, setName] = useState(company?.name ?? "");
  const [margin, setMargin] = useState(company?.default_margin ?? 60);
  const [waPhone, setWaPhone] = useState(company?.whatsapp_phone ?? "");
  const [slug, setSlug] = useState(company?.slug ?? "");

  // Sync quando company carrega após o render
  if (company && name === "" && company.name) setName(company.name);
  if (company && waPhone === "" && company.whatsapp_phone) setWaPhone(company.whatsapp_phone);
  if (company && slug === "" && company.slug) setSlug(company.slug);

  const catalogUrl = company?.slug ? `${window.location.origin}/c/${company.slug}` : null;

  const save = useMutation({
    mutationFn: async () => {
      if (!company) return;
      // Valida slug: apenas letras, números e hifens
      const cleanSlug = slug.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-");
      const { error } = await supabase
        .from("companies")
        .update({
          name: name.trim() || company.name,
          default_margin: margin,
          whatsapp_phone: waPhone.trim() || null,
          slug: cleanSlug || company.slug,
        })
        .eq("id", company.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Configurações salvas");
      refetch();
      qc.invalidateQueries();
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="px-6 py-8 lg:px-10 max-w-3xl">
      <PageHeader title="Configurações" description="Gerencie sua confeitaria e sua conta." />

      <div className="space-y-5">
        {/* Dados da confeitaria */}
        <div className="rounded-2xl border bg-card p-6 shadow-soft">
          <h2 className="font-display text-lg font-bold">Sua confeitaria</h2>
          <div className="mt-4 space-y-3">
            <div>
              <Label>Nome</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <Label>Margem padrão (%)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                value={margin}
                onChange={(e) => setMargin(Number(e.target.value))}
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Margem de lucro padrão usada ao calcular preços de receitas. Mínimo recomendado: 50%.
              </p>
            </div>
            <div>
              <Label>WhatsApp da confeitaria</Label>
              <Input
                value={waPhone}
                onChange={(e) => setWaPhone(e.target.value)}
                placeholder="(11) 99999-0000"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Número para contato e mensagens automáticas. Inclua o DDD.
              </p>
            </div>
            <div>
              <Label>Slug do cardápio público</Label>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground whitespace-nowrap">/c/</span>
                <Input
                  value={slug}
                  onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))}
                  placeholder="minha-confeitaria"
                />
                {catalogUrl && (
                  <Button size="icon" variant="outline" asChild>
                    <a href={catalogUrl} target="_blank" rel="noreferrer">
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </Button>
                )}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                URL pública do seu cardápio digital. Apenas letras minúsculas, números e hifens.
              </p>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <Button
              onClick={() => save.mutate()}
              disabled={save.isPending}
              className="gradient-primary border-0 text-primary-foreground"
            >
              {save.isPending ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </div>

        {/* Conta */}
        <div className="rounded-2xl border bg-card p-6 shadow-soft">
          <h2 className="font-display text-lg font-bold">Conta</h2>
          <div className="mt-3 space-y-1 text-sm">
            <div className="text-muted-foreground">Email</div>
            <div className="font-medium">{user?.email}</div>
            <div className="mt-2 text-xs text-muted-foreground">
              User ID: <code className="text-[10px]">{user?.id}</code>
            </div>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={async () => {
                const { data, error } = await supabase.rpc("claim_super_admin" as any);
                if (error) { toast.error(error.message); return; }
                if ((data as any)?.promoted) toast.success("Você agora é Super Admin! Recarregando…");
                else if ((data as any)?.already) toast.info("Você já é Super Admin.");
                setTimeout(() => window.location.reload(), 1200);
              }}
            >
              Reivindicar Super Admin
            </Button>
            <Button variant="outline" onClick={signOut}>Sair</Button>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            O botão "Reivindicar Super Admin" só funciona se nenhum admin existir ainda — útil para o dono da plataforma.
          </p>
        </div>
      </div>
    </div>
  );
}
