import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useCompany } from "@/lib/company-context";
import { slugify } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles } from "lucide-react";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/onboarding")({
  component: OnboardingPage,
});

const schema = z.object({
  name: z.string().min(2, "Informe o nome").max(80),
  default_margin: z.coerce.number().min(0).max(95).default(60),
});

function OnboardingPage() {
  const { user, loading } = useAuth();
  const { company, refetch } = useCompany();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const form = useForm({ resolver: zodResolver(schema), defaultValues: { name: "", default_margin: 60 } });

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
    if (company) navigate({ to: "/app" });
  }, [user, loading, company, navigate]);

  const onSubmit = form.handleSubmit(async (values) => {
    if (!user) return;
    setSubmitting(true);
    const slug = `${slugify(values.name)}-${Math.random().toString(36).slice(2, 6)}`;
    const { error } = await supabase.from("companies").insert({
      name: values.name,
      slug,
      default_margin: values.default_margin,
      owner_id: user.id,
    });
    setSubmitting(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Empresa criada! Bora começar ✨");
    await refetch();
    navigate({ to: "/app" });
  });

  if (loading || !user) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="relative min-h-screen bg-background">
      <div className="absolute inset-0 gradient-hero pointer-events-none" />
      <div className="relative mx-auto flex min-h-screen max-w-xl items-center justify-center p-6">
        <div className="w-full animate-in-up rounded-3xl border bg-card p-8 shadow-elegant">
          <div className="mb-6">
            <Link to="/"><Logo size={36} /></Link>
          </div>
          <div className="inline-flex items-center gap-1.5 rounded-full border bg-secondary px-3 py-1 text-xs font-medium">
            <Sparkles className="h-3.5 w-3.5 text-accent" /> Passo 1 de 1
          </div>
          <h1 className="mt-4 font-display text-3xl font-bold tracking-tight">Vamos criar sua confeitaria</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">Em 30 segundos você está lá dentro.</p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div>
              <Label>Nome da sua confeitaria</Label>
              <Input placeholder="Ex: Doces da Ju" {...form.register("name")} />
              {form.formState.errors.name && <p className="mt-1 text-xs text-destructive">{form.formState.errors.name.message}</p>}
            </div>
            <div>
              <Label>Margem de lucro padrão (%)</Label>
              <Input type="number" step="1" {...form.register("default_margin")} />
              <p className="mt-1 text-xs text-muted-foreground">Recomendado: 60%. Você pode ajustar depois.</p>
            </div>
            <Button type="submit" disabled={submitting} className="w-full gradient-primary border-0 text-primary-foreground">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Criar e continuar"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
