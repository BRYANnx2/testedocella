import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { Button } from "@/components/ui/button";
import { Plus, ChefHat, ArrowRight, Wand2 } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { formatBRL } from "@/lib/format";

export const Route = createFileRoute("/app/pricing/")({
  component: RecipesList,
});

function RecipesList() {
  const { company } = useCompany();
  const { data, isLoading } = useQuery({
    queryKey: ["recipes", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("recipes")
        .select("id,name,description,servings,suggested_price,is_active,updated_at")
        .eq("company_id", company!.id)
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <>
      <PageHeader
        title="Precificação"
        description="Crie suas receitas e descubra o preço ideal com lucro garantido."
        actions={
          <div className="flex gap-2">
            <Link to="/app/pricing/easy">
              <Button className="gradient-primary border-0 text-primary-foreground"><Wand2 className="h-4 w-4" /> Modo fácil</Button>
            </Link>
            <Link to="/app/pricing/recipes/$id" params={{ id: "new" }}>
              <Button variant="outline"><Plus className="h-4 w-4" /> Avançado</Button>
            </Link>
          </div>
        }
      />
      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-32 rounded-2xl border bg-card animate-pulse" />)}
        </div>
      ) : !data || data.length === 0 ? (
        <EmptyState
          icon={ChefHat}
          title="Nenhuma receita ainda"
          description="Comece criando sua primeira ficha técnica para descobrir quanto cobrar."
          action={{ label: "Criar com modo fácil ✨", onClick: () => { window.location.href = "/app/pricing/easy"; } }}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((r) => (
            <Link
              key={r.id}
              to="/app/pricing/recipes/$id"
              params={{ id: r.id }}
              className="group rounded-2xl border bg-card p-5 shadow-soft transition hover:shadow-elegant hover:-translate-y-0.5"
            >
              <div className="flex items-start justify-between">
                <h3 className="font-display text-lg font-bold leading-tight">{r.name}</h3>
                <ArrowRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5" />
              </div>
              {r.description && <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{r.description}</p>}
              <div className="mt-4 flex items-baseline gap-2">
                <span className="font-display text-2xl font-bold text-primary">{formatBRL(r.suggested_price ?? 0)}</span>
                <span className="text-xs text-muted-foreground">· {r.servings} porções</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
