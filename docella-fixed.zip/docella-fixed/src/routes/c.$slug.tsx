import { createFileRoute, useParams, notFound } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sparkles, ShoppingBag, Plus, Minus, Check, Loader2 } from "lucide-react";
import { Logo } from "@/components/logo";
import { formatBRL } from "@/lib/format";
import { toast } from "sonner";

export const Route = createFileRoute("/c/$slug")({
  head: ({ loaderData }: any) => ({
    meta: [
      { title: loaderData?.company ? `${loaderData.company.name} — Cardápio` : "Cardápio" },
      { name: "description", content: loaderData?.company?.catalog_description ?? "Faça seu pedido pelo cardápio digital." },
    ],
  }),
  component: PublicCatalog,
});

interface CatalogRecipe {
  id: string;
  name: string;
  description: string | null;
  public_description: string | null;
  cover_url: string | null;
  servings: number;
  suggested_price: number | null;
  price_override: number | null;
}

function priceOf(r: CatalogRecipe): number {
  return Number(r.price_override ?? r.suggested_price ?? 0);
}

function PublicCatalog() {
  const { slug } = useParams({ from: "/c/$slug" });
  const [cart, setCart] = useState<Record<string, number>>({});
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const { data, isLoading, error } = useQuery({
    queryKey: ["catalog", slug],
    queryFn: async () => {
      const { data: company, error: cErr } = await supabase
        .from("companies")
        .select("id, name, slug, logo_url, catalog_headline, catalog_description, whatsapp_phone")
        .eq("slug", slug)
        .maybeSingle();
      if (cErr) throw cErr;
      if (!company) throw notFound();
      const { data: recipes, error: rErr } = await supabase
        .from("recipes")
        .select("id, name, description, public_description, cover_url, servings, suggested_price, price_override")
        .eq("company_id", company.id)
        .eq("is_active", true)
        .eq("show_in_catalog", true)
        .order("name");
      if (rErr) throw rErr;
      return { company, recipes: (recipes ?? []) as CatalogRecipe[] };
    },
  });

  const cartItems = useMemo(() => {
    if (!data) return [];
    return data.recipes.filter((r) => (cart[r.id] ?? 0) > 0).map((r) => ({
      recipe: r, qty: cart[r.id], lineTotal: priceOf(r) * cart[r.id],
    }));
  }, [cart, data]);

  const total = cartItems.reduce((s, i) => s + i.lineTotal, 0);
  const totalQty = cartItems.reduce((s, i) => s + i.qty, 0);

  const setQty = (id: string, delta: number) => {
    setCart((c) => {
      const next = Math.max(0, (c[id] ?? 0) + delta);
      if (next === 0) { const { [id]: _, ...rest } = c; return rest; }
      return { ...c, [id]: next };
    });
  };

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }
  if (error || !data) {
    return (
      <div className="flex min-h-screen items-center justify-center px-6 text-center">
        <div>
          <h1 className="font-display text-2xl font-bold">Cardápio não encontrado</h1>
          <p className="mt-2 text-sm text-muted-foreground">Confira o link e tente novamente.</p>
        </div>
      </div>
    );
  }

  const { company, recipes } = data;

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Hero */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero" />
        <div className="relative mx-auto max-w-3xl px-6 pt-12 pb-10 text-center animate-in-up">
          {company.logo_url ? (
            <img src={company.logo_url} alt={company.name} className="mx-auto h-20 w-20 rounded-2xl object-cover shadow-elegant" />
          ) : (
            <div className="mx-auto h-20 w-20 rounded-2xl gradient-primary shadow-glow" />
          )}
          <h1 className="mt-5 font-display text-4xl font-extrabold tracking-tight">{company.name}</h1>
          {company.catalog_headline && <p className="mt-2 text-base text-muted-foreground">{company.catalog_headline}</p>}
          {company.catalog_description && <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">{company.catalog_description}</p>}
          <span className="mt-5 inline-flex items-center gap-1.5 rounded-full border bg-card/80 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-accent" /> Cardápio digital
          </span>
        </div>
      </header>

      {/* Catálogo */}
      <main className="mx-auto max-w-3xl px-4 sm:px-6 -mt-2">
        {recipes.length === 0 ? (
          <div className="rounded-2xl border bg-card p-10 text-center text-sm text-muted-foreground shadow-soft">
            Em breve novos sabores por aqui 🍰
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {recipes.map((r) => {
              const qty = cart[r.id] ?? 0;
              return (
                <article key={r.id} className="overflow-hidden rounded-2xl border bg-card shadow-soft transition hover:shadow-elegant">
                  {r.cover_url ? (
                    <img src={r.cover_url} alt={r.name} className="aspect-video w-full object-cover" />
                  ) : (
                    <div className="aspect-video w-full gradient-primary opacity-30" />
                  )}
                  <div className="p-4">
                    <h3 className="font-display text-lg font-bold leading-tight">{r.name}</h3>
                    {(r.public_description || r.description) && (
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{r.public_description ?? r.description}</p>
                    )}
                    <div className="mt-3 flex items-center justify-between">
                      <span className="font-display text-xl font-bold text-primary">{formatBRL(priceOf(r))}</span>
                      {qty === 0 ? (
                        <Button size="sm" onClick={() => setQty(r.id, +1)} className="gradient-primary border-0 text-primary-foreground">
                          <Plus className="h-3.5 w-3.5" /> Adicionar
                        </Button>
                      ) : (
                        <div className="flex items-center gap-1.5 rounded-full border bg-background p-0.5">
                          <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full" onClick={() => setQty(r.id, -1)}><Minus className="h-3.5 w-3.5" /></Button>
                          <span className="min-w-[1.5rem] text-center text-sm font-semibold tabular-nums">{qty}</span>
                          <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full" onClick={() => setQty(r.id, +1)}><Plus className="h-3.5 w-3.5" /></Button>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </main>

      {/* Footer "Powered by" */}
      <footer className="mt-12 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
        feito com <span className="text-primary">♥</span> via <Logo size={16} withWordmark wordmarkClassName="text-xs" />
      </footer>

      {/* Cart sticky */}
      {totalQty > 0 && (
        <div className="fixed bottom-4 left-1/2 z-30 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 animate-in-up">
          <Button onClick={() => setCheckoutOpen(true)} size="lg" className="w-full gradient-primary border-0 text-primary-foreground shadow-elegant h-14 text-base">
            <ShoppingBag className="h-5 w-5" />
            <span className="flex-1 text-left">{totalQty} {totalQty === 1 ? "item" : "itens"}</span>
            <span className="font-display tabular-nums">{formatBRL(total)}</span>
          </Button>
        </div>
      )}

      <CheckoutDialog
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        companyId={company.id}
        cartItems={cartItems}
        total={total}
        onSuccess={() => { setCart({}); setCheckoutOpen(false); }}
      />
    </div>
  );
}

function CheckoutDialog({
  open, onOpenChange, companyId, cartItems, total, onSuccess,
}: {
  open: boolean; onOpenChange: (b: boolean) => void; companyId: string;
  cartItems: { recipe: CatalogRecipe; qty: number; lineTotal: number }[]; total: number; onSuccess: () => void;
}) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [done, setDone] = useState(false);

  const submit = useMutation({
    mutationFn: async () => {
      if (!name.trim() || !phone.trim()) throw new Error("Informe nome e WhatsApp");
      // 1. cliente
      const { data: customer, error: cErr } = await supabase
        .from("customers")
        .insert({ company_id: companyId, name: name.trim(), phone: phone.trim(), address: address.trim() || null })
        .select("id").single();
      if (cErr) throw cErr;

      // 2. pedido
      const { data: order, error: oErr } = await supabase
        .from("orders")
        .insert({
          company_id: companyId,
          customer_id: customer.id,
          status: "quote_sent",
          payment_status: "pending",
          delivery_date: date || null,
          delivery_address: address.trim() || null,
          notes: notes.trim() || null,
          subtotal: total, total, source: "catalog",
        } as any)
        .select("id").single();
      if (oErr) throw oErr;

      // 3. itens
      const itemsPayload = cartItems.map((i) => ({
        order_id: order.id,
        recipe_id: i.recipe.id,
        name: i.recipe.name,
        quantity: i.qty,
        unit_price: priceOf(i.recipe),
        total: i.lineTotal,
      }));
      const { error: iErr } = await supabase.from("order_items").insert(itemsPayload);
      if (iErr) throw iErr;
      return order.id;
    },
    onSuccess: () => {
      setDone(true);
      toast.success("Pedido enviado! ✨");
      setTimeout(() => { onSuccess(); setDone(false); setName(""); setPhone(""); setDate(""); setAddress(""); setNotes(""); }, 1800);
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        {done ? (
          <div className="py-8 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/15">
              <Check className="h-8 w-8 text-success" />
            </div>
            <h2 className="mt-4 font-display text-2xl font-bold">Pedido enviado!</h2>
            <p className="mt-1 text-sm text-muted-foreground">A confeitaria entrará em contato pelo WhatsApp em breve.</p>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="font-display">Finalizar pedido</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              {/* Resumo carrinho */}
              <div className="rounded-lg bg-secondary/40 p-3 text-sm space-y-1">
                {cartItems.map((i) => (
                  <div key={i.recipe.id} className="flex justify-between">
                    <span>{i.qty}× {i.recipe.name}</span>
                    <span className="tabular-nums">{formatBRL(i.lineTotal)}</span>
                  </div>
                ))}
                <div className="mt-1.5 flex justify-between border-t pt-1.5 font-semibold">
                  <span>Total</span>
                  <span className="tabular-nums text-primary">{formatBRL(total)}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div><Label>Seu nome</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
                <div><Label>WhatsApp</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(11) 99999-0000" /></div>
              </div>
              <div><Label>Data desejada</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
              <div><Label>Endereço (se for entrega)</Label><Input value={address} onChange={(e) => setAddress(e.target.value)} /></div>
              <div><Label>Observações</Label><Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Recheio, cor, mensagem..." /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)}>Voltar</Button>
              <Button className="gradient-primary border-0 text-primary-foreground" onClick={() => submit.mutate()} disabled={submit.isPending}>
                {submit.isPending ? "Enviando..." : "Enviar pedido"}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
