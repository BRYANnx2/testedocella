import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Sparkles, Calculator, ClipboardList, MessageCircle, TrendingUp, Heart } from "lucide-react";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Docella — Precifique, venda mais e tenha paz financeira" },
      { name: "description", content: "SaaS para confeiteiras: precificação inteligente, cardápio digital, gestão de pedidos e WhatsApp. Comece grátis por 14 dias." },
      { property: "og:title", content: "Docella — SaaS para confeiteiras" },
      { property: "og:description", content: "Precifique, organize pedidos e cresça com seu negócio doce." },
    ],
  }),
  component: Landing,
});

function Feature({ icon: Icon, title, text }: { icon: any; title: string; text: string }) {
  return (
    <div className="group rounded-2xl border bg-card p-6 shadow-soft transition hover:shadow-elegant">
      <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl gradient-primary text-primary-foreground shadow-glow">
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{text}</p>
    </div>
  );
}

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link to="/"><Logo size={32} /></Link>
          <div className="flex items-center gap-2">
            <Link to="/auth"><Button variant="ghost" size="sm">Entrar</Button></Link>
            <Link to="/auth"><Button size="sm" className="gradient-primary border-0 text-primary-foreground">Começar grátis</Button></Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero pointer-events-none" />
        <div className="relative mx-auto max-w-6xl px-6 pt-20 pb-24 text-center animate-in-up">
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-card/70 px-3 py-1 text-xs font-medium text-muted-foreground shadow-soft backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-accent" />
            Feito para confeiteiras que vendem no Insta e no Zap
          </span>
          <h1 className="mt-6 text-balance font-display text-5xl font-extrabold tracking-tight sm:text-6xl md:text-7xl">
            Pare de chutar preço.<br/>
            <span className="bg-clip-text text-transparent gradient-primary">Comece a lucrar.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-balance text-lg text-muted-foreground">
            Precifique seus doces com precisão, organize seus pedidos e cresça com tranquilidade. Tudo num lugar só, feito pra quem ama o que faz.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/auth">
              <Button size="lg" className="gradient-primary border-0 text-primary-foreground shadow-elegant">
                Começar grátis por 14 dias
              </Button>
            </Link>
            <span className="text-xs text-muted-foreground">Sem cartão de crédito</span>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">Tudo que você precisa pra profissionalizar</h2>
          <p className="mt-3 text-muted-foreground">Sem planilhas confusas. Sem perder pedido no WhatsApp.</p>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <Feature icon={Calculator} title="Precificação inteligente" text="Cadastre ingredientes, monte fichas técnicas e descubra o preço certo com a margem que você quer." />
          <Feature icon={ClipboardList} title="Pedidos organizados" text="Do orçamento à entrega: tudo num pipeline claro. Calendário de produção e controle de sinal e saldo." />
          <Feature icon={MessageCircle} title="WhatsApp sem atrito" text="Mensagens prontas para orçamento, confirmação, lembrete de pagamento e avaliação. 1 clique." />
          <Feature icon={TrendingUp} title="Financeiro em tempo real" text="Veja faturamento, lucro, ticket médio e produtos mais lucrativos sem abrir planilha." />
          <Feature icon={Heart} title="Clientes que voltam" text="Histórico completo, aniversários e campanhas de recompra que fazem a diferença." />
          <Feature icon={Sparkles} title="Simples, de verdade" text="Interface pensada pra quem não tem tempo a perder. Rápido no computador e no celular." />
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-6 pb-24">
        <div className="relative overflow-hidden rounded-3xl gradient-primary p-10 text-center shadow-elegant">
          <h2 className="font-display text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl">
            Comece hoje. Cobre com confiança amanhã.
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/80">
            14 dias grátis. Cancele quando quiser.
          </p>
          <Link to="/auth" className="mt-6 inline-block">
            <Button size="lg" variant="secondary" className="shadow-elegant">Criar minha conta</Button>
          </Link>
        </div>
      </section>

      <footer className="border-t py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Docella. Feito com carinho para quem faz doce.
      </footer>
    </div>
  );
}
