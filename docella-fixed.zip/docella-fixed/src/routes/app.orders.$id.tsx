import { createFileRoute, useNavigate, useParams, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Plus, Trash2, Save, MessageCircle, DollarSign } from "lucide-react";
import { formatBRL, formatDate } from "@/lib/format";
import { renderTemplate, waLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/app/orders/$id")({
  component: OrderEditor,
});

interface OrderItem { id?: string; recipe_id: string | null; name: string; quantity: number; unit_price: number; }
interface OrderData {
  id: string;
  order_number?: number;
  customer_id: string | null;
  status: string;
  payment_status: string;
  delivery_date: string | null;
  delivery_time: string | null;
  delivery_address: string | null;
  discount: number;
  deposit: number;
  notes: string | null;
}

const STATUSES = ["quote_sent", "confirmed", "in_production", "ready", "delivered", "canceled"];
const STATUS_LABEL: Record<string, string> = {
  quote_sent: "Orçamento enviado", confirmed: "Confirmado", in_production: "Em produção", ready: "Pronto", delivered: "Entregue", canceled: "Cancelado",
};

function OrderEditor() {
  const { id } = useParams({ from: "/app/orders/$id" });
  const isNew = id === "new";
  const { company } = useCompany();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [order, setOrder] = useState<OrderData>({
    id: "", customer_id: null, status: "quote_sent", payment_status: "pending",
    delivery_date: null, delivery_time: null, delivery_address: null, discount: 0, deposit: 0, notes: null,
  });
  const [items, setItems] = useState<OrderItem[]>([]);

  const { data: customers } = useQuery({
    queryKey: ["customers-list", company?.id], enabled: !!company,
    queryFn: async () => { const { data } = await supabase.from("customers").select("id,name,phone").eq("company_id", company!.id).order("name"); return data ?? []; },
  });
  const { data: recipes } = useQuery({
    queryKey: ["recipes-list", company?.id], enabled: !!company,
    queryFn: async () => { const { data } = await supabase.from("recipes").select("id,name,suggested_price").eq("company_id", company!.id).eq("is_active", true).order("name"); return data ?? []; },
  });
  const { data: templates } = useQuery({
    queryKey: ["wa-templates", company?.id], enabled: !!company,
    queryFn: async () => { const { data } = await supabase.from("whatsapp_templates").select("*").eq("company_id", company!.id); return data ?? []; },
  });

  const { data: existing } = useQuery({
    queryKey: ["order", id], enabled: !isNew,
    queryFn: async () => {
      const [{ data: o }, { data: it }, { data: pay }] = await Promise.all([
        supabase.from("orders").select("*").eq("id", id).single(),
        supabase.from("order_items").select("*").eq("order_id", id),
        supabase.from("payments").select("*").eq("order_id", id).order("paid_at"),
      ]);
      return { o, it, pay };
    },
  });

  useEffect(() => {
    if (existing?.o) {
      setOrder(existing.o as any);
      setItems((existing.it ?? []).map((i: any) => ({ id: i.id, recipe_id: i.recipe_id, name: i.name, quantity: Number(i.quantity), unit_price: Number(i.unit_price) })));
    }
  }, [existing]);

  const subtotal = useMemo(() => items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0), [items]);
  const total = Math.max(0, subtotal - Number(order.discount || 0));
  const paidAmount = (existing?.pay ?? []).reduce((s: number, p: any) => s + Number(p.amount), 0);
  const balance = Math.max(0, total - paidAmount - Number(order.deposit || 0));

  const customer = customers?.find((c) => c.id === order.customer_id);

  const save = useMutation({
    mutationFn: async () => {
      if (!company) throw new Error("Empresa não carregada");
      if (!order.customer_id) throw new Error("Selecione um cliente");
      if (items.length === 0) throw new Error("Adicione pelo menos um item");
      const payload = {
        company_id: company.id,
        customer_id: order.customer_id,
        status: order.status as any,
        payment_status: order.payment_status as any,
        delivery_date: order.delivery_date,
        delivery_time: order.delivery_time,
        delivery_address: order.delivery_address,
        subtotal, discount: Number(order.discount) || 0, total, deposit: Number(order.deposit) || 0,
        notes: order.notes,
      };
      let orderId = order.id;
      if (isNew) {
        const { data, error } = await supabase.from("orders").insert(payload).select("id").single();
        if (error) throw error;
        orderId = data.id;
      } else {
        const { error } = await supabase.from("orders").update(payload).eq("id", orderId);
        if (error) throw error;
        await supabase.from("order_items").delete().eq("order_id", orderId);
      }
      const itemsPayload = items.map((i) => ({ order_id: orderId, recipe_id: i.recipe_id, name: i.name, quantity: Number(i.quantity), unit_price: Number(i.unit_price), total: Number(i.quantity) * Number(i.unit_price) }));
      if (itemsPayload.length) {
        const { error } = await supabase.from("order_items").insert(itemsPayload);
        if (error) throw error;
      }
      return orderId;
    },
    onSuccess: (orderId) => {
      toast.success("Pedido salvo!");
      qc.invalidateQueries({ queryKey: ["orders"] });
      qc.invalidateQueries({ queryKey: ["order", orderId] });
      if (isNew) navigate({ to: "/app/orders/$id", params: { id: orderId } });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const addItemFromRecipe = (recipeId: string) => {
    const r = recipes?.find((x) => x.id === recipeId);
    if (!r) return;
    setItems((arr) => [...arr, { recipe_id: r.id, name: r.name, quantity: 1, unit_price: Number(r.suggested_price ?? 0) }]);
  };

  const sendWa = (trigger: string) => {
    const tpl = templates?.find((t: any) => t.trigger === trigger);
    if (!tpl || !customer) { toast.error("Selecione cliente e configure templates"); return; }
    const detalhes = items.map((i) => `${i.quantity}x ${i.name}`).join(", ");
    const msg = renderTemplate(tpl.body, {
      cliente: customer.name, total, detalhes, data: order.delivery_date, sinal: order.deposit, saldo: balance, endereco: order.delivery_address ?? "",
    });
    window.open(waLink(customer.phone, msg), "_blank");
  };

  return (
    <div className="px-6 py-8 lg:px-10">
      <Link to="/app/orders" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Voltar
      </Link>

      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">{isNew ? "Novo pedido" : `Pedido #${existing?.o?.order_number ?? ""}`}</h1>
          {!isNew && <p className="text-sm text-muted-foreground">Criado em {formatDate(existing?.o?.created_at)}</p>}
        </div>
        <Button onClick={() => save.mutate()} disabled={save.isPending} className="gradient-primary border-0 text-primary-foreground">
          <Save className="h-4 w-4" /> {save.isPending ? "Salvando..." : "Salvar"}
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-5">
          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <h2 className="font-display text-lg font-bold">Cliente & entrega</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div>
                <Label>Cliente</Label>
                <select value={order.customer_id ?? ""} onChange={(e) => setOrder({ ...order, customer_id: e.target.value || null })} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
                  <option value="">— Selecione —</option>
                  {customers?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <Link to="/app/customers" className="mt-1 inline-block text-xs text-primary hover:underline">Cadastrar cliente</Link>
              </div>
              <div>
                <Label>Status</Label>
                <select value={order.status} onChange={(e) => setOrder({ ...order, status: e.target.value })} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
                  {STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
                </select>
              </div>
              <div><Label>Data de entrega</Label><Input type="date" value={order.delivery_date ?? ""} onChange={(e) => setOrder({ ...order, delivery_date: e.target.value || null })} /></div>
              <div><Label>Horário</Label><Input type="time" value={order.delivery_time ?? ""} onChange={(e) => setOrder({ ...order, delivery_time: e.target.value || null })} /></div>
              <div className="sm:col-span-2"><Label>Endereço de entrega</Label><Input value={order.delivery_address ?? ""} onChange={(e) => setOrder({ ...order, delivery_address: e.target.value || null })} /></div>
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold">Itens</h2>
              <select onChange={(e) => { if (e.target.value) { addItemFromRecipe(e.target.value); e.target.value = ""; } }} defaultValue="" className="h-9 rounded-md border bg-background px-2 text-sm">
                <option value="">+ Adicionar receita</option>
                {recipes?.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </div>
            <Button size="sm" variant="ghost" className="mt-2 -ml-2" onClick={() => setItems((a) => [...a, { recipe_id: null, name: "", quantity: 1, unit_price: 0 }])}>
              <Plus className="h-3.5 w-3.5" /> Item personalizado
            </Button>
            {items.length === 0 && <p className="mt-3 text-sm text-muted-foreground">Adicione receitas ou itens personalizados.</p>}
            {items.length > 0 && (
              <div className="mt-3 space-y-2">
                {items.map((it, idx) => (
                  <div key={idx} className="grid grid-cols-12 items-center gap-2 rounded-lg border bg-background/50 p-2">
                    <Input className="col-span-5" value={it.name} onChange={(e) => setItems((a) => a.map((x, i) => i === idx ? { ...x, name: e.target.value } : x))} placeholder="Descrição" />
                    <Input className="col-span-2" type="number" step="any" value={it.quantity} onChange={(e) => setItems((a) => a.map((x, i) => i === idx ? { ...x, quantity: Number(e.target.value) } : x))} />
                    <Input className="col-span-2" type="number" step="0.01" value={it.unit_price} onChange={(e) => setItems((a) => a.map((x, i) => i === idx ? { ...x, unit_price: Number(e.target.value) } : x))} />
                    <span className="col-span-2 text-right text-sm tabular-nums">{formatBRL(it.quantity * it.unit_price)}</span>
                    <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setItems((a) => a.filter((_, i) => i !== idx))}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <h2 className="font-display text-lg font-bold">Observações</h2>
            <Textarea className="mt-3" rows={3} value={order.notes ?? ""} onChange={(e) => setOrder({ ...order, notes: e.target.value })} placeholder="Detalhes do pedido, recheio especial, alergias..." />
          </div>

          {!isNew && (
            <PaymentsSection orderId={order.id} balance={balance} onChange={() => qc.invalidateQueries({ queryKey: ["order", order.id] })} payments={existing?.pay ?? []} />
          )}
        </div>

        <aside className="lg:sticky lg:top-6 h-fit space-y-4">
          <div className="rounded-2xl border bg-card p-5 shadow-elegant">
            <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Resumo</h3>
            <div className="mt-3 space-y-1.5 text-sm">
              <Row label="Subtotal" value={formatBRL(subtotal)} />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Desconto</span>
                <Input type="number" step="0.01" value={order.discount} onChange={(e) => setOrder({ ...order, discount: Number(e.target.value) })} className="h-8 w-24 text-right" />
              </div>
              <div className="my-2 border-t" />
              <Row label="Total" value={formatBRL(total)} className="font-display text-xl font-bold text-primary" />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Sinal</span>
                <Input type="number" step="0.01" value={order.deposit} onChange={(e) => setOrder({ ...order, deposit: Number(e.target.value) })} className="h-8 w-24 text-right" />
              </div>
              {!isNew && <Row label="Pago" value={formatBRL(paidAmount)} className="text-success" />}
              {!isNew && <Row label="Saldo" value={formatBRL(balance)} bold />}
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <h3 className="font-display text-sm font-bold flex items-center gap-1.5"><MessageCircle className="h-4 w-4 text-success" /> Enviar pelo WhatsApp</h3>
            <div className="mt-3 grid gap-2">
              <Button variant="outline" size="sm" onClick={() => sendWa("quote")} disabled={!customer}>Orçamento</Button>
              <Button variant="outline" size="sm" onClick={() => sendWa("confirmation")} disabled={!customer}>Confirmação</Button>
              <Button variant="outline" size="sm" onClick={() => sendWa("payment_reminder")} disabled={!customer}>Lembrete pagamento</Button>
              <Button variant="outline" size="sm" onClick={() => sendWa("delivery_reminder")} disabled={!customer}>Lembrete entrega</Button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Row({ label, value, bold, className = "" }: { label: string; value: string; bold?: boolean; className?: string }) {
  return (
    <div className={`flex items-center justify-between ${className}`}>
      <span className={bold ? "font-semibold" : "text-muted-foreground"}>{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}

function PaymentsSection({ orderId, balance, payments, onChange }: { orderId: string; balance: number; payments: any[]; onChange: () => void }) {
  const [amount, setAmount] = useState<number>(0);
  const [method, setMethod] = useState("pix");

  const addPayment = useMutation({
    mutationFn: async () => {
      if (!amount || amount <= 0) throw new Error("Valor inválido");
      const { error } = await supabase.from("payments").insert({ order_id: orderId, amount, method: method as any });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Pagamento registrado"); setAmount(0); onChange(); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft">
      <h2 className="font-display text-lg font-bold flex items-center gap-1.5"><DollarSign className="h-4 w-4" /> Pagamentos</h2>
      <div className="mt-3 grid grid-cols-12 gap-2">
        <Input className="col-span-4" type="number" step="0.01" placeholder="Valor" value={amount || ""} onChange={(e) => setAmount(Number(e.target.value))} />
        <select value={method} onChange={(e) => setMethod(e.target.value)} className="col-span-4 h-10 rounded-md border bg-background px-3 text-sm">
          <option value="pix">PIX</option>
          <option value="cash">Dinheiro</option>
          <option value="card">Cartão</option>
          <option value="transfer">Transferência</option>
          <option value="other">Outro</option>
        </select>
        <Button className="col-span-4" onClick={() => addPayment.mutate()} disabled={addPayment.isPending}>Registrar</Button>
      </div>
      {payments.length > 0 && (
        <div className="mt-4 space-y-1.5">
          {payments.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded-lg bg-secondary/40 px-3 py-2 text-sm">
              <span className="text-muted-foreground">{formatDate(p.paid_at)} · {p.method}</span>
              <span className="font-medium tabular-nums">{formatBRL(p.amount)}</span>
            </div>
          ))}
        </div>
      )}
      <p className="mt-3 text-xs text-muted-foreground">Saldo restante: <strong className="text-foreground">{formatBRL(balance)}</strong></p>
    </div>
  );
}
