import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { formatBRL } from "@/lib/format";
import { TrendingUp, ClipboardList, Users, Package, ArrowUpRight, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/app/")({
  component: DashboardPage,
});

function Stat({ label, value, icon: Icon, hint }: { label: string; value: string; icon: any; hint?: string }) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft transition hover:shadow-elegant">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</span>
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="mt-3 font-display text-3xl font-bold tracking-tight">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}

const TIPS = [
  "Margem abaixo de 50% em doces artesanais costuma deixar a confeiteira no prejuízo quando consideramos tempo e custos fixos. Revise seus preços no módulo Precificação sempre que trocar fornecedor.",
  "Compartilhe o link do seu Cardápio Digital no Stories do Instagram — é uma das formas mais fáceis de receber pedidos sem precisar responder tudo pelo WhatsApp.",
  "Cadastre o aniversário dos seus clientes para criar campanhas de recompra certeiras. Clientes fiéis gastam em média 3x mais que novos clientes.",
  "Sempre registre o sinal (entrada) do pedido — isso reduz cancelamentos e garante cobertura dos seus custos de produção.",
  "Foto boa vende. Adicione fotos de capa às suas receitas e elas aparecerão mais atrativas no cardápio público.",
];

const weekTip = TIPS[new Date().getDay() % TIPS.length];

function DashboardPage() {
  const { company } = useCompany();

  const { data, isLoading } = useQuery({
    queryKey: ["dashboard", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      const [{ data: orders }, { count: customerCount }, { count: productCount }] = await Promise.all([
        supabase
          .from("orders")
          .select("id,total,status,delivery_date,created_at")
          .eq("company_id", company!.id)
          .gte("created_at", monthStart.toISOString()),
        supabase
          .from("customers")
          .select("id", { count: "exact", head: true })
          .eq("company_id", company!.id),
        supabase
          .from("recipes")
          .select("id", { count: "exact", head: true })
          .eq("company_id", company!.id),
      ]);
      const revenue = (orders ?? [])
        .filter((o) => !["canceled"].includes(o.status))
        .reduce((s, o) => s + Number(o.total || 0), 0);
      const inProgress = (orders ?? []).filter((o) =>
        ["confirmed", "in_production", "ready"].includes(o.status)
      ).length;
      return {
        revenue,
        inProgress,
        customerCount: customerCount ?? 0,
        productCount: productCount ?? 0,
        orderCount: (orders ?? []).length,
      };
    },
  });

  const steps = [
    { label: "Cadastre seus ingredientes", to: "/app/pricing/ingredients", done: false },
    { label: "Monte sua primeira receita", to: "/app/pricing", done: (data?.productCount ?? 0) > 0 },
    { label: "Configure seu cardápio público", to: "/app/catalog", done: false },
    { label: "Registre seu primeiro pedido", to: "/app/orders", done: (data?.orderCount ?? 0) > 0 },
  ];

  const pendingSteps = steps.filter((s) => !s.done);

  return (
    <div className="relative">
      <div className="absolute inset-x-0 top-0 h-64 gradient-hero pointer-events-none" />
      <div className="relative px-6 py-8 lg:px-10">
        <header className="animate-in-up">
          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Olá, bem-vinda de volta
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold tracking-tight">{company?.name}</h1>
          <p className="mt-1 text-sm text-muted-foreground">Aqui está o resumo do seu mês até agora.</p>
        </header>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat
            label="Faturamento (mês)"
            value={isLoading ? "—" : formatBRL(data?.revenue ?? 0)}
            icon={TrendingUp}
            hint={`${data?.orderCount ?? 0} pedidos`}
          />
          <Stat
            label="Em andamento"
            value={isLoading ? "—" : String(data?.inProgress ?? 0)}
            icon={ClipboardList}
            hint="Pedidos ativos"
          />
          <Stat
            label="Clientes"
            value={isLoading ? "—" : String(data?.customerCount ?? 0)}
            icon={Users}
            hint="Cadastrados"
          />
          <Stat
            label="Produtos"
            value={isLoading ? "—" : String(data?.productCount ?? 0)}
            icon={Package}
            hint="Com preço definido"
          />
        </div>

        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <div className="rounded-2xl border bg-card p-6 shadow-soft">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold">Próximos passos</h2>
            </div>
            {pendingSteps.length === 0 ? (
              <div className="mt-4 flex items-center gap-2 text-sm text-success">
                <CheckCircle2 className="h-4 w-4" />
                Tudo configurado! Você está pronta para vender.
              </div>
            ) : (
              <ul className="mt-4 space-y-2 text-sm">
                {pendingSteps.map((step) => (
                  <li key={step.to}>
                    <Link
                      to={step.to}
                      className="flex items-center justify-between rounded-lg bg-secondary/60 px-3 py-2.5 transition hover:bg-secondary"
                    >
                      <span>{step.label}</span>
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="rounded-2xl border bg-card p-6 shadow-soft">
            <h2 className="font-display text-lg font-bold">Dica da semana</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
              {weekTip}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
