import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Users, ClipboardList, DollarSign, TrendingUp, Sparkles, RefreshCw } from "lucide-react";
import { formatBRL } from "@/lib/format";

export const Route = createFileRoute("/admin/")({
  component: AdminOverview,
});

interface Stats {
  total_companies: number;
  total_users: number;
  total_orders: number;
  total_revenue: number;
  active_subscriptions: number;
  paying_subscriptions: number;
  mrr_cents: number;
  companies_last_30d: number;
  orders_last_30d: number;
}

function AdminOverview() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadStats() {
    setLoading(true);
    setError(null);
    try {
      const { data, error: rpcError } = await supabase.rpc("platform_stats" as any);
      if (rpcError) {
        // Fallback: busca dados diretamente das tabelas
        const [
          { count: companies },
          { count: users },
          { count: orders },
          { data: revenueData },
          { count: activeSubs },
        ] = await Promise.all([
          supabase.from("companies").select("id", { count: "exact", head: true }),
          supabase.from("profiles").select("id", { count: "exact", head: true }),
          supabase.from("orders").select("id", { count: "exact", head: true }),
          supabase.from("orders").select("total").neq("status", "canceled"),
          supabase.from("subscriptions").select("id", { count: "exact", head: true }).eq("status", "active"),
        ]);
        const totalRevenue = (revenueData ?? []).reduce((s: number, o: any) => s + Number(o.total || 0), 0);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const [{ count: recentCompanies }, { count: recentOrders }] = await Promise.all([
          supabase.from("companies").select("id", { count: "exact", head: true }).gte("created_at", thirtyDaysAgo.toISOString()),
          supabase.from("orders").select("id", { count: "exact", head: true }).gte("created_at", thirtyDaysAgo.toISOString()),
        ]);
        setStats({
          total_companies: companies ?? 0,
          total_users: users ?? 0,
          total_orders: orders ?? 0,
          total_revenue: totalRevenue,
          active_subscriptions: activeSubs ?? 0,
          paying_subscriptions: activeSubs ?? 0,
          mrr_cents: (activeSubs ?? 0) * 4990,
          companies_last_30d: recentCompanies ?? 0,
          orders_last_30d: recentOrders ?? 0,
        });
      } else if (data) {
        setStats(data as Stats);
      }
    } catch (err: any) {
      setError(err.message ?? "Erro ao carregar métricas");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadStats(); }, []);

  const cards = stats
    ? [
        { label: "Empresas", value: stats.total_companies, icon: Building2, hint: `+${stats.companies_last_30d} em 30d` },
        { label: "Usuários", value: stats.total_users, icon: Users },
        { label: "Pedidos totais", value: stats.total_orders, icon: ClipboardList, hint: `+${stats.orders_last_30d} em 30d` },
        { label: "GMV processado", value: formatBRL(Number(stats.total_revenue || 0)), icon: DollarSign },
        { label: "Assinaturas ativas", value: stats.active_subscriptions, icon: Sparkles, hint: `${stats.paying_subscriptions} pagantes` },
        { label: "MRR estimado", value: formatBRL((stats.mrr_cents || 0) / 100), icon: TrendingUp },
      ]
    : [];

  return (
    <div className="p-6 lg:p-10">
      <PageHeader
        title="Visão geral da plataforma"
        description="Métricas em tempo real do Docella."
        actions={
          <Button variant="outline" size="sm" onClick={loadStats} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            {loading ? "Carregando..." : "Atualizar"}
          </Button>
        }
      />

      {loading && !stats ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="h-28 animate-pulse bg-secondary/40" />
          ))}
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-destructive">
          <strong>Erro ao carregar métricas:</strong> {error}
          <Button variant="outline" size="sm" className="mt-3 block" onClick={loadStats}>Tentar novamente</Button>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {cards.map((c) => (
            <Card key={c.label} className="p-5">
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">{c.label}</div>
                <c.icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="mt-2 font-display text-3xl font-bold">{c.value}</div>
              {c.hint && <div className="mt-1 text-xs text-muted-foreground">{c.hint}</div>}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
