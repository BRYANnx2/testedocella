import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, ChefHat, Sparkles, Plus, Trash2, Check, Wand2 } from "lucide-react";
import { computeRecipe, type IngredientLite } from "@/lib/pricing";
import { formatBRL } from "@/lib/format";
import { toast } from "sonner";

export const Route = createFileRoute("/app/pricing/easy")({
  component: EasyPricing,
});

interface QuickItem { ingredient_id: string; quantity: number; unit: string; }

function EasyPricing() {
  const { company } = useCompany();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [servings, setServings] = useState(8);
  const [items, setItems] = useState<QuickItem[]>([]);
  const [extraCost, setExtraCost] = useState(0); // mão de obra + embalagem somados
  const [margin, setMargin] = useState(60);

  const { data: ingredientsList } = useQuery({
    queryKey: ["ingredients-list", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data } = await supabase.from("ingredients").select("*").eq("company_id", company!.id).order("name");
      return (data ?? []) as IngredientLite[];
    },
  });

  const ingredientsMap = useMemo(() => {
    const m = new Map<string, IngredientLite>();
    (ingredientsList ?? []).forEach((i) => m.set(i.id, i));
    return m;
  }, [ingredientsList]);

  const computed = useMemo(() => computeRecipe({
    items, ingredients: ingredientsMap,
    laborCost: extraCost, fixedCost: 0, packagingCost: 0,
    desiredMargin: margin, servings,
  }), [items, ingredientsMap, extraCost, margin, servings]);

  const save = useMutation({
    mutationFn: async () => {
      if (!company) throw new Error("Empresa não carregada");
      if (!name.trim()) throw new Error("Dê um nome pra sua receita");
      const { data: r, error } = await supabase.from("recipes").insert({
        company_id: company.id,
        name: name.trim(),
        servings, yield_qty: 1, yield_unit: "un",
        labor_cost: extraCost, fixed_cost: 0, packaging_cost: 0,
        desired_margin: margin,
        suggested_price: computed.suggestedPrice,
      }).select("id").single();
      if (error) throw error;
      if (items.length > 0) {
        await supabase.from("recipe_items").insert(items.filter(i => i.ingredient_id && i.quantity > 0).map(i => ({
          recipe_id: r.id, ingredient_id: i.ingredient_id, quantity: i.quantity, unit: i.unit,
        })));
      }
      return r.id;
    },
    onSuccess: (id) => {
      toast.success("Receita criada! 🎂");
      qc.invalidateQueries({ queryKey: ["recipes"] });
      navigate({ to: "/app/pricing/recipes/$id", params: { id } });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const noIngredients = !ingredientsList || ingredientsList.length === 0;

  return (
    <div className="px-6 py-8 lg:px-10 max-w-3xl mx-auto">
      <Link to="/app/pricing" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Voltar
      </Link>

      <div className="flex items-center gap-2 mb-2">
        <Wand2 className="h-5 w-5 text-accent" />
        <h1 className="font-display text-2xl font-bold">Modo fácil</h1>
      </div>
      <p className="text-muted-foreground mb-6">Em 3 passos descubra quanto cobrar pela sua delícia 💛</p>

      {/* Stepper */}
      <div className="flex items-center gap-2 mb-6">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex items-center gap-2 flex-1">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold ${step >= s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
              {step > s ? <Check className="h-4 w-4" /> : s}
            </div>
            {s < 3 && <div className={`h-0.5 flex-1 ${step > s ? "bg-primary" : "bg-muted"}`} />}
          </div>
        ))}
      </div>

      {/* Step 1: Nome + porções */}
      {step === 1 && (
        <Card className="p-6 space-y-4">
          <h2 className="font-display text-xl font-bold">O que você está fazendo?</h2>
          <div>
            <Label>Nome da receita</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Bolo de chocolate molhadinho" />
          </div>
          <div>
            <Label>Quantas porções/unidades essa receita rende?</Label>
            <Input type="number" value={servings} onChange={(e) => setServings(Number(e.target.value))} />
            <p className="text-xs text-muted-foreground mt-1">Exemplo: bolo serve 10 fatias = 10. Caixa com 6 brigadeiros = 6.</p>
          </div>
          <Button className="w-full" disabled={!name.trim()} onClick={() => setStep(2)}>Continuar <ArrowRight className="h-4 w-4" /></Button>
        </Card>
      )}

      {/* Step 2: Ingredientes */}
      {step === 2 && (
        <Card className="p-6 space-y-4">
          <h2 className="font-display text-xl font-bold">O que vai dentro?</h2>
          {noIngredients ? (
            <div className="text-center py-8 space-y-3">
              <ChefHat className="h-12 w-12 mx-auto text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Você ainda não cadastrou ingredientes.</p>
              <Link to="/app/pricing/ingredients"><Button variant="outline">Cadastrar ingredientes primeiro</Button></Link>
            </div>
          ) : (
            <>
              <div className="space-y-2">
                {items.map((it, idx) => {
                  const ing = ingredientsMap.get(it.ingredient_id);
                  const cost = ing ? (ing.package_cost / ing.package_size) * it.quantity : 0;
                  return (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center rounded-lg border p-2">
                      <select value={it.ingredient_id} onChange={(e) => {
                        const ni = ingredientsList?.find(x => x.id === e.target.value);
                        setItems(arr => arr.map((x, i) => i === idx ? { ...x, ingredient_id: e.target.value, unit: ni?.unit ?? x.unit } : x));
                      }} className="col-span-6 h-9 rounded-md border bg-background px-2 text-sm">
                        {ingredientsList?.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
                      </select>
                      <Input className="col-span-3" type="number" step="any" value={it.quantity} onChange={(e) => setItems(arr => arr.map((x, i) => i === idx ? { ...x, quantity: Number(e.target.value) } : x))} />
                      <span className="col-span-1 text-xs text-muted-foreground">{it.unit}</span>
                      <span className="col-span-1 text-xs text-right tabular-nums">{formatBRL(cost)}</span>
                      <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setItems(arr => arr.filter((_, i) => i !== idx))}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  );
                })}
              </div>
              <Button variant="outline" className="w-full" onClick={() => setItems(arr => [...arr, { ingredient_id: ingredientsList![0].id, quantity: 0, unit: ingredientsList![0].unit }])}>
                <Plus className="h-4 w-4" /> Adicionar ingrediente
              </Button>

              <div className="pt-2">
                <Label>Quanto cobrar por mão de obra + embalagem? (R$)</Label>
                <Input type="number" step="0.01" value={extraCost} onChange={(e) => setExtraCost(Number(e.target.value))} placeholder="0,00" />
                <p className="text-xs text-muted-foreground mt-1">Tempo gasto + caixinha/sacola/laço. Não sabe? Coloque 0 e ajustamos depois.</p>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(1)}>Voltar</Button>
                <Button className="flex-1" onClick={() => setStep(3)}>Ver preço sugerido <ArrowRight className="h-4 w-4" /></Button>
              </div>
            </>
          )}
        </Card>
      )}

      {/* Step 3: Resultado */}
      {step === 3 && (
        <Card className="p-6 space-y-5 bg-gradient-to-br from-primary/5 to-accent/5">
          <div className="text-center">
            <Sparkles className="h-8 w-8 mx-auto text-accent mb-2" />
            <h2 className="font-display text-xl font-bold">Pronto! Esse é seu preço</h2>
            <div className="font-display text-5xl font-bold text-primary mt-3">{formatBRL(computed.suggestedPrice)}</div>
            <p className="text-sm text-muted-foreground mt-1">{formatBRL(computed.pricePerServing)} por porção</p>
          </div>

          <div className="space-y-2">
            <Label>Margem de lucro: <strong className="text-primary">{margin}%</strong></Label>
            <input type="range" min={20} max={90} value={margin} onChange={(e) => setMargin(Number(e.target.value))} className="w-full accent-primary" />
            <div className="flex justify-between text-xs text-muted-foreground"><span>Baixa (20%)</span><span>Boa (60%)</span><span>Alta (90%)</span></div>
          </div>

          <div className="rounded-lg bg-card p-4 space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Custo dos ingredientes</span><span className="tabular-nums">{formatBRL(computed.ingredientsCost)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Mão de obra + embalagem</span><span className="tabular-nums">{formatBRL(extraCost)}</span></div>
            <div className="flex justify-between border-t pt-1.5"><span className="font-medium">Custo total</span><span className="tabular-nums font-medium">{formatBRL(computed.totalCost)}</span></div>
            <div className="flex justify-between text-success"><span className="font-medium">Seu lucro 💛</span><span className="tabular-nums font-bold">{formatBRL(computed.profit)}</span></div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setStep(2)}>Ajustar</Button>
            <Button className="flex-1 gradient-primary border-0 text-primary-foreground" onClick={() => save.mutate()} disabled={save.isPending}>
              {save.isPending ? "Salvando..." : "Salvar receita"}
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
