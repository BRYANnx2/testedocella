import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Users, MessageCircle } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { waLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/app/customers")({
  component: CustomersPage,
});

interface Customer { id: string; name: string; phone: string | null; email: string | null; address: string | null; notes: string | null; }

function CustomersPage() {
  const { company } = useCompany();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [search, setSearch] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["customers", company?.id], enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase.from("customers").select("*").eq("company_id", company!.id).order("name");
      if (error) throw error;
      return (data ?? []) as Customer[];
    },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from("customers").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => { toast.success("Cliente removido"); qc.invalidateQueries({ queryKey: ["customers"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  const filtered = (data ?? []).filter((c) => !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.phone?.includes(search));

  return (
    <div className="px-6 py-8 lg:px-10">
      <PageHeader
        title="Clientes"
        description="Sua base de clientes, sempre à mão."
        actions={<Button onClick={() => { setEditing(null); setOpen(true); }} className="gradient-primary border-0 text-primary-foreground"><Plus className="h-4 w-4" /> Novo cliente</Button>}
      />

      <div className="mb-4">
        <Input placeholder="Buscar por nome ou telefone..." value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-sm" />
      </div>

      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 rounded-xl border bg-card animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={Users} title="Nenhum cliente" description="Cadastre seus clientes para acompanhar pedidos e histórico." action={{ label: "Cadastrar cliente", onClick: () => { setEditing(null); setOpen(true); } }} />
      ) : (
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <div key={c.id} className="rounded-2xl border bg-card p-4 shadow-soft transition hover:shadow-elegant">
              <div className="flex items-start justify-between">
                <div className="min-w-0">
                  <div className="font-display text-base font-bold truncate">{c.name}</div>
                  {c.phone && <div className="mt-0.5 text-xs text-muted-foreground">{c.phone}</div>}
                  {c.email && <div className="text-xs text-muted-foreground truncate">{c.email}</div>}
                </div>
                <div className="flex gap-0.5">
                  {c.phone && (
                    <Button asChild size="icon" variant="ghost" title="Abrir WhatsApp">
                      <a href={waLink(c.phone, `Olá ${c.name}!`)} target="_blank" rel="noreferrer">
                        <MessageCircle className="h-3.5 w-3.5 text-success" />
                      </a>
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(c); setOpen(true); }}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => { if (confirm(`Remover ${c.name}?`)) remove.mutate(c.id); }}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <CustomerDialog open={open} onOpenChange={setOpen} editing={editing} companyId={company?.id} />
    </div>
  );
}

function CustomerDialog({ open, onOpenChange, editing, companyId }: { open: boolean; onOpenChange: (b: boolean) => void; editing: Customer | null; companyId?: string }) {
  const qc = useQueryClient();
  const [name, setName] = useState(editing?.name ?? "");
  const [phone, setPhone] = useState(editing?.phone ?? "");
  const [email, setEmail] = useState(editing?.email ?? "");
  const [address, setAddress] = useState(editing?.address ?? "");
  const [notes, setNotes] = useState(editing?.notes ?? "");

  // Sync when editing changes
  if (open && editing && name !== editing.name && name === "") {
    setName(editing.name); setPhone(editing.phone ?? ""); setEmail(editing.email ?? ""); setAddress(editing.address ?? ""); setNotes(editing.notes ?? "");
  }

  const save = useMutation({
    mutationFn: async () => {
      if (!companyId || !name.trim()) throw new Error("Informe o nome");
      const payload = { name: name.trim(), phone: phone.trim() || null, email: email.trim() || null, address: address.trim() || null, notes: notes.trim() || null, company_id: companyId };
      if (editing) { const { error } = await supabase.from("customers").update(payload).eq("id", editing.id); if (error) throw error; }
      else { const { error } = await supabase.from("customers").insert(payload); if (error) throw error; }
    },
    onSuccess: () => {
      toast.success(editing ? "Cliente atualizado" : "Cliente cadastrado");
      qc.invalidateQueries({ queryKey: ["customers"] });
      onOpenChange(false);
      setName(""); setPhone(""); setEmail(""); setAddress(""); setNotes("");
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) { setName(""); setPhone(""); setEmail(""); setAddress(""); setNotes(""); } }}>
      <DialogContent>
        <DialogHeader><DialogTitle>{editing ? "Editar cliente" : "Novo cliente"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Telefone</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(11) 99999-0000" /></div>
            <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          </div>
          <div><Label>Endereço</Label><Input value={address} onChange={(e) => setAddress(e.target.value)} /></div>
          <div><Label>Observações</Label><Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Aniversário, preferências..." /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button className="gradient-primary border-0 text-primary-foreground" onClick={() => save.mutate()} disabled={save.isPending}>{save.isPending ? "Salvando..." : "Salvar"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
