import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/admin/audit")({
  component: AdminAudit,
});

function AdminAudit() {
  const [logs, setLogs] = useState<any[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("audit_logs" as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      setLogs((data as any) ?? []);
    })();
  }, []);

  const filtered = logs.filter((l) =>
    !q || l.table_name?.includes(q) || l.action?.includes(q.toUpperCase())
  );

  const actionColor = (a: string) =>
    a === "INSERT" ? "default" : a === "UPDATE" ? "secondary" : "destructive";

  return (
    <div className="p-6 lg:p-10">
      <PageHeader title="Auditoria" description="Últimas 200 alterações no sistema (todas as empresas)" />
      <div className="mb-4 max-w-sm">
        <Input placeholder="Filtrar por tabela ou ação…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <Card className="divide-y overflow-hidden">
        {filtered.map((l) => (
          <div key={l.id} className="flex items-start justify-between gap-4 px-4 py-3 text-sm">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <Badge variant={actionColor(l.action) as any}>{l.action}</Badge>
                <span className="font-mono text-xs">{l.table_name}</span>
                {l.record_id && <span className="truncate text-xs text-muted-foreground">#{String(l.record_id).slice(0, 8)}</span>}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                user: {l.user_id ? String(l.user_id).slice(0, 8) : "—"} · empresa: {l.company_id ? String(l.company_id).slice(0, 8) : "—"}
              </div>
            </div>
            <div className="shrink-0 text-xs text-muted-foreground">
              {new Date(l.created_at).toLocaleString("pt-BR")}
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">Sem registros.</div>}
      </Card>
    </div>
  );
}
