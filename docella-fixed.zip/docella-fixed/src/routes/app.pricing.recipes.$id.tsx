import { createFileRoute, useNavigate, useParams, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Plus, Trash2, Save, Sparkles } from "lucide-react";
import { computeRecipe, type IngredientLite } from "@/lib/pricing";
import { formatBRL } from "@/lib/format";

export const Route = createFileRoute("/app/pricing/recipes/$id")({
  component: RecipeEditor,
});

interface RecipeData {
  id: string;
  name: string;
  description: string | null;
  servings: number;
  yield_qty: number;
  yield_unit: string;
  labor_cost: number;
  fixed_cost: number;
  packaging_cost: number;
  desired_margin: number;
  suggested_price: number | null;
  is_active: boolean;
}

interface Item { id?: string; ingredient_id: string; quantity: number; unit: string; }

function RecipeEditor() {
  const { id } = useParams({ from: "/app/pricing/recipes/$id" });
  const isNew = id === "new";
  const { company } = useCompany();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [recipe, setRecipe] = useState<RecipeData>({
    id: "", name: "", description: "", servings: 8, yield_qty: 1, yield_unit: "un",
    labor_cost: 0, fixed_cost: 0, packaging_cost: 0, desired_margin: company?.default_margin ?? 60, suggested_price: null, is_active: true,
  });
  const [items, setItems] = useState<Item[]>([]);

  const { data: ingredientsList } = useQuery({
    queryKey: ["ingredients-list", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase.from("ingredients").select("*").eq("company_id", company!.id).order("name");
      if (error) throw error;
      return (data ?? []) as IngredientLite[];
    },
  });

  const { data: existing, isLoading } = useQuery({
    queryKey: ["recipe", id],
    enabled: !isNew && !!company,
    queryFn: async () => {
      const [{ data: r, error: e1 }, { data: it, error: e2 }] = await Promise.all([
        supabase.from("recipes").select("*").eq("id", id).single(),
        supabase.from("recipe_items").select("*").eq("recipe_id", id),
      ]);
      if (e1) throw e1; if (e2) throw e2;
      return { r, it };
    },
  });

  useEffect(() => {
    if (existing?.r) {
      setRecipe(existing.r as RecipeData);
      setItems((existing.it ?? []).map((i: any) => ({ id: i.id, ingredient_id: i.ingredient_id, quantity: Number(i.quantity), unit: i.unit })));
    }
  }, [existing]);

  const ingredientsMap = useMemo(() => {
    const m = new Map<string, IngredientLite>();
    (ingredientsList ?? []).forEach((i) => m.set(i.id, i));
    return m;
  }, [ingredientsList]);

  const computed = useMemo(() => computeRecipe({
    items, ingredients: ingredientsMap,
    laborCost: Number(recipe.labor_cost) || 0,
    fixedCost: Number(recipe.fixed_cost) || 0,
    packagingCost: Number(recipe.packaging_cost) || 0,
    desiredMargin: Number(recipe.desired_margin) || 0,
    servings: Number(recipe.servings) || 1,
  }), [items, ingredientsMap, recipe]);

  const save = useMutation({
    mutationFn: async () => {
      if (!company) throw new Error("Empresa não carregada");
      if (!recipe.name.trim()) throw new Error("Informe o nome da receita");
      const payload = {
        name: recipe.name.trim(),
        description: recipe.description,
        servings: Number(recipe.servings) || 1,
        yield_qty: Number(recipe.yield_qty) || 1,
        yield_unit: recipe.yield_unit,
        labor_cost: Number(recipe.labor_cost) || 0,
        fixed_cost: Number(recipe.fixed_cost) || 0,
        packaging_cost: Number(recipe.packaging_cost) || 0,
        desired_margin: Number(recipe.desired_margin) || 0,
        suggested_price: computed.suggestedPrice,
        is_active: recipe.is_active,
        company_id: company.id,
      };

      let recipeId = recipe.id;
      if (isNew) {
        const { data, error } = await supabase.from("recipes").insert(payload).select("id").single();
        if (error) throw error;
        recipeId = data.id;
      } else {
        const { error } = await supabase.from("recipes").update(payload).eq("id", recipeId);
        if (error) throw error;
        // wipe & re-insert items (simpler than diff)
        await supabase.from("recipe_items").delete().eq("recipe_id", recipeId);
      }
      if (items.length > 0) {
        const itemsPayload = items
          .filter((i) => i.ingredient_id && Number(i.quantity) > 0)
          .map((i) => ({ recipe_id: recipeId, ingredient_id: i.ingredient_id, quantity: Number(i.quantity), unit: i.unit }));
        if (itemsPayload.length) {
          const { error } = await supabase.from("recipe_items").insert(itemsPayload);
          if (error) throw error;
        }
      }
      return recipeId;
    },
    onSuccess: (recipeId) => {
      toast.success("Receita salva!");
      qc.invalidateQueries({ queryKey: ["recipes"] });
      qc.invalidateQueries({ queryKey: ["recipe", recipeId] });
      if (isNew) navigate({ to: "/app/pricing/recipes/$id", params: { id: recipeId } });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const addItem = () => setItems((l) => [...l, { ingredient_id: ingredientsList?.[0]?.id ?? "", quantity: 0, unit: ingredientsList?.[0]?.unit ?? "g" }]);

  if (!isNew && isLoading) return <div className="p-10 text-sm text-muted-foreground">Carregando...</div>;

  return (
    <div className="px-6 py-8 lg:px-10">
      <Link to="/app/pricing" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Voltar
      </Link>
      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-5">
          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <h2 className="font-display text-lg font-bold">Informações</h2>
            <div className="mt-4 space-y-3">
              <div><Label>Nome</Label><Input value={recipe.name} onChange={(e) => setRecipe({ ...recipe, name: e.target.value })} placeholder="Ex: Bolo de chocolate" /></div>
              <div><Label>Descrição</Label><Textarea rows={2} value={recipe.description ?? ""} onChange={(e) => setRecipe({ ...recipe, description: e.target.value })} /></div>
              <div className="grid grid-cols-3 gap-3">
                <div><Label>Porções</Label><Input type="number" value={recipe.servings} onChange={(e) => setRecipe({ ...recipe, servings: Number(e.target.value) })} /></div>
                <div><Label>Rendimento</Label><Input type="number" step="any" value={recipe.yield_qty} onChange={(e) => setRecipe({ ...recipe, yield_qty: Number(e.target.value) })} /></div>
                <div><Label>Unidade</Label><Input value={recipe.yield_unit} onChange={(e) => setRecipe({ ...recipe, yield_unit: e.target.value })} /></div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold">Ingredientes</h2>
              <Button size="sm" variant="outline" onClick={addItem} disabled={!ingredientsList || ingredientsList.length === 0}><Plus className="h-3.5 w-3.5" /> Adicionar</Button>
            </div>
            {(!ingredientsList || ingredientsList.length === 0) && (
              <p className="mt-3 text-sm text-muted-foreground">
                Você ainda não tem ingredientes. <Link to="/app/pricing/ingredients" className="font-medium text-primary hover:underline">Cadastrar agora</Link>.
              </p>
            )}
            {items.length > 0 && (
              <div className="mt-4 space-y-2">
                {items.map((it, idx) => {
                  const ing = ingredientsMap.get(it.ingredient_id);
                  const lineCost = ing ? (ing.package_cost / ing.package_size) * Number(it.quantity || 0) : 0;
                  return (
                    <div key={idx} className="grid grid-cols-12 items-center gap-2 rounded-lg border bg-background/50 p-2">
                      <select value={it.ingredient_id} onChange={(e) => { const newIng = ingredientsList?.find(x => x.id === e.target.value); setItems((arr) => arr.map((x, i) => i === idx ? { ...x, ingredient_id: e.target.value, unit: newIng?.unit ?? x.unit } : x)); }} className="col-span-6 h-9 rounded-md border bg-background px-2 text-sm">
                        {ingredientsList?.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
                      </select>
                      <Input className="col-span-2" type="number" step="any" value={it.quantity} onChange={(e) => setItems((arr) => arr.map((x, i) => i === idx ? { ...x, quantity: Number(e.target.value) } : x))} />
                      <span className="col-span-1 text-xs text-muted-foreground">{it.unit}</span>
                      <span className="col-span-2 text-right text-sm tabular-nums">{formatBRL(lineCost)}</span>
                      <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setItems((arr) => arr.filter((_, i) => i !== idx))}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="rounded-2xl border bg-card p-5 shadow-soft">
            <h2 className="font-display text-lg font-bold">Custos adicionais</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div><Label>Mão de obra (R$)</Label><Input type="number" step="0.01" value={recipe.labor_cost} onChange={(e) => setRecipe({ ...recipe, labor_cost: Number(e.target.value) })} /></div>
              <div><Label>Custos fixos (R$)</Label><Input type="number" step="0.01" value={recipe.fixed_cost} onChange={(e) => setRecipe({ ...recipe, fixed_cost: Number(e.target.value) })} /></div>
              <div><Label>Embalagem (R$)</Label><Input type="number" step="0.01" value={recipe.packaging_cost} onChange={(e) => setRecipe({ ...recipe, packaging_cost: Number(e.target.value) })} /></div>
            </div>
          </div>
        </div>

        <aside className="lg:sticky lg:top-6 h-fit space-y-4">
          <div className="rounded-2xl border bg-card p-5 shadow-elegant">
            <div className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-accent">
              <Sparkles className="h-3.5 w-3.5" /> Preço sugerido
            </div>
            <div className="mt-2 font-display text-4xl font-bold text-primary">{formatBRL(computed.suggestedPrice)}</div>
            <div className="mt-1 text-xs text-muted-foreground">{formatBRL(computed.pricePerServing)} por porção</div>

            <div className="mt-5">
              <Label>Margem de lucro (%)</Label>
              <Input type="number" value={recipe.desired_margin} onChange={(e) => setRecipe({ ...recipe, desired_margin: Number(e.target.value) })} />
            </div>

            <div className="mt-5 space-y-1.5 text-sm">
              <Row label="Ingredientes" value={formatBRL(computed.ingredientsCost)} />
              <Row label="Mão de obra" value={formatBRL(computed.laborCost)} />
              <Row label="Custos fixos" value={formatBRL(computed.fixedCost)} />
              <Row label="Embalagem" value={formatBRL(computed.packagingCost)} />
              <div className="my-2 border-t" />
              <Row label="Custo total" value={formatBRL(computed.totalCost)} bold />
              <Row label="Lucro" value={formatBRL(computed.profit)} className="text-success" bold />
            </div>
          </div>

          <Button className="w-full gradient-primary border-0 text-primary-foreground shadow-elegant" onClick={() => save.mutate()} disabled={save.isPending}>
            <Save className="h-4 w-4" /> {save.isPending ? "Salvando..." : "Salvar receita"}
          </Button>
        </aside>
      </div>
    </div>
  );
}

function Row({ label, value, bold, className = "" }: { label: string; value: string; bold?: boolean; className?: string }) {
  return (
    <div className={`flex items-center justify-between ${className}`}>
      <span className="text-muted-foreground">{label}</span>
      <span className={`tabular-nums ${bold ? "font-semibold text-foreground" : ""}`}>{value}</span>
    </div>
  );
}
