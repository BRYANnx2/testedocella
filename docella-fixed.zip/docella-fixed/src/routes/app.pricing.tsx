import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/pricing")({
  component: PricingLayout,
});

const tabs = [
  { to: "/app/pricing", label: "Receitas", exact: true },
  { to: "/app/pricing/ingredients", label: "Ingredientes" },
];

function PricingLayout() {
  const { location } = useRouterState();
  return (
    <div className="px-6 py-8 lg:px-10">
      <div className="mb-6 flex gap-1 rounded-xl border bg-card p-1 shadow-soft w-fit">
        {tabs.map((t) => {
          const active = t.exact ? location.pathname === t.to : location.pathname.startsWith(t.to);
          return (
            <Link
              key={t.to}
              to={t.to}
              className={cn(
                "rounded-lg px-4 py-1.5 text-sm font-medium transition",
                active ? "bg-secondary text-secondary-foreground shadow-soft" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t.label}
            </Link>
          );
        })}
      </div>
      <Outlet />
    </div>
  );
}
