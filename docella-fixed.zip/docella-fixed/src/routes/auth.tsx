import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";
import { Logo } from "@/components/logo";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Entrar — Docella" }] }),
  component: AuthPage,
});

const signUpSchema = z.object({
  full_name: z.string().min(2, "Informe seu nome").max(80),
  email: z.string().email("Email inválido").max(200),
  password: z.string().min(8, "Mínimo 8 caracteres").max(72),
});
const signInSchema = z.object({
  email: z.string().email("Email inválido").max(200),
  password: z.string().min(1, "Informe a senha").max(72),
});

function AuthPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<"signin" | "signup">("signin");
  const [oauthLoading, setOauthLoading] = useState(false);

  const signIn = useForm({ resolver: zodResolver(signInSchema), defaultValues: { email: "", password: "" } });
  const signUp = useForm({ resolver: zodResolver(signUpSchema), defaultValues: { full_name: "", email: "", password: "" } });

  const onSignIn = signIn.handleSubmit(async (values) => {
    const { error } = await supabase.auth.signInWithPassword(values);
    if (error) { toast.error(error.message); return; }
    toast.success("Bem-vinda de volta!");
    navigate({ to: "/app" });
  });

  const onSignUp = signUp.handleSubmit(async (values) => {
    const { error } = await supabase.auth.signUp({
      email: values.email,
      password: values.password,
      options: {
        emailRedirectTo: typeof window !== "undefined" ? window.location.origin : undefined,
        data: { full_name: values.full_name },
      },
    });
    if (error) { toast.error(error.message); return; }
    toast.success("Conta criada! Vamos começar.");
    navigate({ to: "/onboarding" });
  });

  const onGoogle = async () => {
    setOauthLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: typeof window !== "undefined" ? window.location.origin + "/app" : undefined,
    });
    if (result.error) { toast.error("Falha ao entrar com Google"); setOauthLoading(false); return; }
    if (!result.redirected) navigate({ to: "/app" });
  };

  return (
    <div className="flex min-h-screen">
      <div className="hidden flex-1 relative overflow-hidden lg:flex">
        <div className="absolute inset-0 gradient-primary" />
        <div className="absolute inset-0 gradient-hero opacity-60" />
        <div className="relative z-10 flex flex-col justify-between p-12 text-primary-foreground">
          <Link to="/" className="flex items-center gap-2 text-primary-foreground">
            <span className="font-display text-2xl font-bold tracking-tight">Docella</span>
          </Link>
          <div className="animate-in-up">
            <h2 className="font-display text-4xl font-bold leading-tight">
              "Descobri que estava vendendo meu bolo 40% mais barato. Mudou tudo."
            </h2>
            <p className="mt-4 text-primary-foreground/80">Juliana · Doceria artesanal</p>
          </div>
        </div>
      </div>

      <div className="flex flex-1 items-center justify-center bg-background p-6">
        <div className="w-full max-w-md animate-in-up">
          <div className="mb-8 lg:hidden">
            <Link to="/"><Logo size={36} /></Link>
          </div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Bem-vinda 💛</h1>
          <p className="mt-1 text-sm text-muted-foreground">Entre ou crie sua conta para começar.</p>

          <Button onClick={onGoogle} variant="outline" className="mt-6 w-full" disabled={oauthLoading}>
            {oauthLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (
              <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            )}
            Continuar com Google
          </Button>
          <div className="relative my-6"><div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div><div className="relative flex justify-center text-xs"><span className="bg-background px-2 text-muted-foreground">ou com email</span></div></div>

          <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Entrar</TabsTrigger>
              <TabsTrigger value="signup">Criar conta</TabsTrigger>
            </TabsList>
            <TabsContent value="signin">
              <form onSubmit={onSignIn} className="space-y-3 pt-4">
                <div>
                  <Label>Email</Label>
                  <Input type="email" autoComplete="email" {...signIn.register("email")} />
                  {signIn.formState.errors.email && <p className="mt-1 text-xs text-destructive">{signIn.formState.errors.email.message}</p>}
                </div>
                <div>
                  <Label>Senha</Label>
                  <Input type="password" autoComplete="current-password" {...signIn.register("password")} />
                  {signIn.formState.errors.password && <p className="mt-1 text-xs text-destructive">{signIn.formState.errors.password.message}</p>}
                </div>
                <Button type="submit" className="w-full gradient-primary border-0 text-primary-foreground" disabled={signIn.formState.isSubmitting}>
                  {signIn.formState.isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Entrar"}
                </Button>
              </form>
            </TabsContent>
            <TabsContent value="signup">
              <form onSubmit={onSignUp} className="space-y-3 pt-4">
                <div>
                  <Label>Nome</Label>
                  <Input type="text" autoComplete="name" {...signUp.register("full_name")} />
                  {signUp.formState.errors.full_name && <p className="mt-1 text-xs text-destructive">{signUp.formState.errors.full_name.message}</p>}
                </div>
                <div>
                  <Label>Email</Label>
                  <Input type="email" autoComplete="email" {...signUp.register("email")} />
                  {signUp.formState.errors.email && <p className="mt-1 text-xs text-destructive">{signUp.formState.errors.email.message}</p>}
                </div>
                <div>
                  <Label>Senha</Label>
                  <Input type="password" autoComplete="new-password" {...signUp.register("password")} />
                  {signUp.formState.errors.password && <p className="mt-1 text-xs text-destructive">{signUp.formState.errors.password.message}</p>}
                </div>
                <Button type="submit" className="w-full gradient-primary border-0 text-primary-foreground" disabled={signUp.formState.isSubmitting}>
                  {signUp.formState.isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Criar conta grátis"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
