import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company-context";
import { Button } from "@/components/ui/button";
import { Plus, ClipboardList, ArrowRight, Zap, Globe } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { formatBRL, formatDate } from "@/lib/format";
import { useState } from "react";
import { QuickOrderDialog } from "@/components/quick-order-dialog";

export const Route = createFileRoute("/app/orders")({
  component: OrdersList,
});

const STATUS = {
  quote_sent: { label: "Orçamento", color: "bg-secondary text-secondary-foreground" },
  confirmed: { label: "Confirmado", color: "bg-primary/15 text-primary" },
  in_production: { label: "Em produção", color: "bg-warning/20 text-warning-foreground" },
  ready: { label: "Pronto", color: "bg-accent/20 text-accent-foreground" },
  delivered: { label: "Entregue", color: "bg-success/20 text-success" },
  canceled: { label: "Cancelado", color: "bg-destructive/15 text-destructive" },
} as const;

function OrdersList() {
  const { company } = useCompany();
  const [filter, setFilter] = useState<keyof typeof STATUS | "all">("all");
  const [quickOpen, setQuickOpen] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["orders", company?.id],
    enabled: !!company,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("id,order_number,status,payment_status,delivery_date,total,paid_amount,customers(name,phone)")
        .eq("company_id", company!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = (data ?? []).filter((o) => filter === "all" || o.status === filter);

  return (
    <div className="px-6 py-8 lg:px-10">
      <PageHeader
        title="Pedidos"
        description="Do orçamento à entrega — tudo organizado num só lugar."
        actions={
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => setQuickOpen(true)} variant="outline">
              <Zap className="h-4 w-4 text-accent" /> Pedido rápido
            </Button>
            {company && (
              <a href={`/c/${company.slug}`} target="_blank" rel="noreferrer">
                <Button variant="outline"><Globe className="h-4 w-4" /> Ver cardápio público</Button>
              </a>
            )}
            <Link to="/app/orders/$id" params={{ id: "new" }}>
              <Button className="gradient-primary border-0 text-primary-foreground"><Plus className="h-4 w-4" /> Pedido completo</Button>
            </Link>
          </div>
        }
      />

      <QuickOrderDialog open={quickOpen} onOpenChange={setQuickOpen} />

      <div className="mb-4 flex flex-wrap gap-1.5">
        {(["all", ...Object.keys(STATUS)] as const).map((k) => (
          <button
            key={k}
            onClick={() => setFilter(k as any)}
            className={`rounded-full border px-3 py-1 text-xs font-medium transition ${filter === k ? "bg-primary text-primary-foreground border-transparent" : "bg-card hover:bg-muted"}`}
          >
            {k === "all" ? "Todos" : STATUS[k as keyof typeof STATUS].label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-20 rounded-xl border bg-card animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={ClipboardList} title="Nenhum pedido aqui" description="Crie seu primeiro pedido e veja a mágica acontecer." action={{ label: "Criar pedido", onClick: () => { window.location.href = "/app/orders/new"; } }} />
      ) : (
        <div className="grid gap-2.5">
          {filtered.map((o: any) => {
            const s = STATUS[o.status as keyof typeof STATUS];
            return (
              <Link key={o.id} to="/app/orders/$id" params={{ id: o.id }} className="group flex items-center gap-4 rounded-2xl border bg-card p-4 shadow-soft transition hover:shadow-elegant">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-sm font-bold text-secondary-foreground">#{o.order_number}</div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{o.customers?.name ?? "Cliente sem nome"}</span>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${s?.color ?? ""}`}>{s?.label}</span>
                  </div>
                  <div className="mt-0.5 text-xs text-muted-foreground">Entrega: {formatDate(o.delivery_date)}</div>
                </div>
                <div className="text-right">
                  <div className="font-display text-lg font-bold tabular-nums">{formatBRL(o.total)}</div>
                  <div className="text-xs text-muted-foreground">Pago: {formatBRL(o.paid_amount)}</div>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5" />
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
