import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/admin/companies")({
  component: AdminCompanies,
});

function AdminCompanies() {
  const [companies, setCompanies] = useState<any[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("companies")
        .select("id, name, slug, owner_id, created_at, subscriptions(plan, status)")
        .order("created_at", { ascending: false });
      setCompanies(data ?? []);
    })();
  }, []);

  const filtered = companies.filter((c) =>
    !q || c.name?.toLowerCase().includes(q.toLowerCase()) || c.slug?.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="p-6 lg:p-10">
      <PageHeader title="Empresas" description={`${companies.length} confeitarias na plataforma`} />
      <div className="mb-4 max-w-sm">
        <Input placeholder="Buscar por nome ou slug…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <Card className="overflow-hidden">
        <div className="grid grid-cols-12 gap-2 border-b bg-muted/40 px-4 py-2 text-xs font-medium text-muted-foreground">
          <div className="col-span-5">Empresa</div>
          <div className="col-span-3">Plano</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-2">Criada em</div>
        </div>
        {filtered.map((c) => {
          const sub = c.subscriptions?.[0];
          return (
            <div key={c.id} className="grid grid-cols-12 gap-2 border-b px-4 py-3 text-sm last:border-0">
              <div className="col-span-5">
                <div className="font-medium">{c.name}</div>
                <div className="text-xs text-muted-foreground">/{c.slug}</div>
              </div>
              <div className="col-span-3"><Badge variant="secondary">{sub?.plan ?? "—"}</Badge></div>
              <div className="col-span-2 text-muted-foreground">{sub?.status ?? "—"}</div>
              <div className="col-span-2 text-muted-foreground">{new Date(c.created_at).toLocaleDateString("pt-BR")}</div>
            </div>
          );
        })}
        {filtered.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">Nenhuma empresa encontrada.</div>}
      </Card>
    </div>
  );
}
