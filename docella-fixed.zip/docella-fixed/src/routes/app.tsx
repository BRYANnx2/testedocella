import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { useCompany } from "@/lib/company-context";
import {
  LayoutDashboard, Calculator, ClipboardList, Users, Calendar,
  TrendingUp, MessageCircle, Settings, LogOut, Loader2, Shield,
  CreditCard, BookOpen
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/logo";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/app")({
  component: AppShell,
});

const nav = [
  { to: "/app", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/app/pricing", label: "Precificação", icon: Calculator },
  { to: "/app/orders", label: "Pedidos", icon: ClipboardList },
  { to: "/app/customers", label: "Clientes", icon: Users },
  { to: "/app/calendar", label: "Calendário", icon: Calendar },
  { to: "/app/finance", label: "Financeiro", icon: TrendingUp },
  { to: "/app/catalog", label: "Cardápio", icon: BookOpen },
  { to: "/app/whatsapp", label: "WhatsApp", icon: MessageCircle },
  { to: "/app/billing", label: "Assinatura", icon: CreditCard },
  { to: "/app/settings", label: "Configurações", icon: Settings },
];

const mobileNav = [
  { to: "/app", label: "Início", icon: LayoutDashboard, exact: true },
  { to: "/app/orders", label: "Pedidos", icon: ClipboardList },
  { to: "/app/catalog", label: "Cardápio", icon: BookOpen },
  { to: "/app/customers", label: "Clientes", icon: Users },
  { to: "/app/settings", label: "Config", icon: Settings },
];

function AppShell() {
  const { user, loading, signOut } = useAuth();
  const { company, loading: companyLoading } = useCompany();
  const navigate = useNavigate();
  const { location } = useRouterState();
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
    if (!loading && user && !companyLoading && !company) navigate({ to: "/onboarding" });
  }, [user, loading, company, companyLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "super_admin")
      .maybeSingle()
      .then(({ data }) => setIsSuperAdmin(!!data));
  }, [user]);

  if (loading || companyLoading || !user || !company) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar — somente desktop */}
      <aside className="hidden w-64 flex-col border-r bg-sidebar text-sidebar-foreground lg:flex">
        <div className="flex h-16 items-center gap-2 border-b px-5">
          <Logo size={32} withWordmark={false} />
          <div className="leading-tight">
            <div className="font-display text-sm font-bold">{company.name}</div>
            <div className="text-xs text-muted-foreground">Docella · Pro</div>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto p-3">
          {nav.map((item) => {
            const active = item.exact
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-soft"
                    : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t p-3">
          {isSuperAdmin && (
            <Link
              to="/admin"
              className="mb-2 flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-sm font-medium text-primary hover:bg-primary/15"
            >
              <Shield className="h-4 w-4" /> Painel Super Admin
            </Link>
          )}
          <div className="mb-2 rounded-lg bg-secondary p-3 text-xs">
            <div className="font-semibold text-secondary-foreground">Teste grátis</div>
            <div className="text-muted-foreground">Aproveite todos os recursos por 14 dias.</div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={signOut}
            className="w-full justify-start text-muted-foreground"
          >
            <LogOut className="h-4 w-4" /> Sair
          </Button>
        </div>
      </aside>

      {/* Main content — padding-bottom no mobile para não sobrepor a nav */}
      <main className="flex-1 overflow-x-hidden pb-20 lg:pb-0">
        <Outlet />
      </main>

      {/* Mobile bottom navigation */}
      <nav className="fixed bottom-0 inset-x-0 z-40 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 lg:hidden safe-area-inset-bottom">
        <div className="flex h-16 items-stretch">
          {mobileNav.map((item) => {
            const active = item.exact
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors",
                  active ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <item.icon className={cn("h-5 w-5", active && "text-primary")} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
