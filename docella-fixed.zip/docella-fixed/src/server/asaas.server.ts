// Asaas API helpers (server-only)
const BASE_URLS = {
  sandbox: "https://api-sandbox.asaas.com/v3",
  production: "https://api.asaas.com/v3",
};

export function asaasBaseUrl() {
  const env = (process.env.ASAAS_ENV ?? "sandbox").toLowerCase();
  return env === "production" || env === "prod" || env === "live"
    ? BASE_URLS.production
    : BASE_URLS.sandbox;
}

export async function asaasFetch(path: string, init: RequestInit = {}) {
  const apiKey = process.env.ASAAS_API_KEY;
  if (!apiKey) throw new Error("ASAAS_API_KEY não configurada");
  const res = await fetch(`${asaasBaseUrl()}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      access_token: apiKey,
      "User-Agent": "Docella/1.0",
      ...(init.headers ?? {}),
    },
  });
  const text = await res.text();
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch {}
  if (!res.ok) {
    const msg = json?.errors?.[0]?.description || json?.message || `Asaas ${res.status}`;
    throw new Error(`Asaas: ${msg}`);
  }
  return json;
}

export async function getOrCreateCustomer(params: {
  name: string;
  email: string;
  cpfCnpj?: string;
  mobilePhone?: string;
  externalReference?: string;
}) {
  // Try to find by email
  if (params.email) {
    const found = await asaasFetch(`/customers?email=${encodeURIComponent(params.email)}`);
    if (found?.data?.length > 0) return found.data[0];
  }
  return await asaasFetch("/customers", {
    method: "POST",
    body: JSON.stringify(params),
  });
}
