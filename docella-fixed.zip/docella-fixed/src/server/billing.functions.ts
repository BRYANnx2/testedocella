import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { asaasFetch, getOrCreateCustomer } from "./asaas.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const PLANS = {
  pro: { amount: 49.9, name: "Docella Pro - Mensal" },
  premium: { amount: 99.9, name: "Docella Premium - Mensal" },
} as const;

export const createSubscriptionCharge = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      companyId: z.string().uuid(),
      plan: z.enum(["pro", "premium"]),
      billingType: z.enum(["PIX", "CREDIT_CARD", "BOLETO"]).default("PIX"),
      cpfCnpj: z.string().min(11).max(20),
      customerName: z.string().min(2),
      customerEmail: z.string().email(),
      mobilePhone: z.string().optional(),
    }).parse(d)
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // verify user can manage company
    const { data: canManage } = await supabase.rpc("can_manage_company", {
      _user_id: userId,
      _company_id: data.companyId,
    });
    if (!canManage) throw new Error("Sem permissão para gerenciar essa empresa.");

    const plan = PLANS[data.plan];

    // 1. customer
    const customer = await getOrCreateCustomer({
      name: data.customerName,
      email: data.customerEmail,
      cpfCnpj: data.cpfCnpj.replace(/\D/g, ""),
      mobilePhone: data.mobilePhone?.replace(/\D/g, ""),
      externalReference: data.companyId,
    });

    // 2. one-shot payment (next due date = today+1)
    const due = new Date();
    due.setDate(due.getDate() + 3);
    const dueStr = due.toISOString().slice(0, 10);

    const charge = await asaasFetch("/payments", {
      method: "POST",
      body: JSON.stringify({
        customer: customer.id,
        billingType: data.billingType,
        value: plan.amount,
        dueDate: dueStr,
        description: plan.name,
        externalReference: data.companyId,
      }),
    });

    // 3. fetch PIX qrcode if applicable
    let pixQr: any = null;
    if (data.billingType === "PIX" && charge.id) {
      try {
        pixQr = await asaasFetch(`/payments/${charge.id}/pixQrCode`);
      } catch {}
    }

    // 4. persist
    await supabaseAdmin.from("billing_charges").insert({
      company_id: data.companyId,
      asaas_charge_id: charge.id,
      amount: plan.amount,
      status: charge.status ?? "PENDING",
      billing_type: data.billingType,
      due_date: dueStr,
      invoice_url: charge.invoiceUrl ?? null,
      pix_qrcode: pixQr?.encodedImage ?? null,
      pix_copypaste: pixQr?.payload ?? null,
      description: plan.name,
    });

    // store asaas_customer_id on subscription
    await supabaseAdmin
      .from("subscriptions")
      .update({ asaas_customer_id: customer.id })
      .eq("company_id", data.companyId);

    return {
      ok: true,
      chargeId: charge.id,
      invoiceUrl: charge.invoiceUrl,
      pixQrcode: pixQr?.encodedImage ?? null,
      pixCopyPaste: pixQr?.payload ?? null,
      status: charge.status,
    };
  });

export const refreshChargeStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ chargeId: z.string().min(1), companyId: z.string().uuid() }).parse(d)
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: canManage } = await supabase.rpc("can_manage_company", {
      _user_id: userId,
      _company_id: data.companyId,
    });
    if (!canManage) throw new Error("Sem permissão.");

    const remote = await asaasFetch(`/payments/${data.chargeId}`);
    const isPaid = ["RECEIVED", "CONFIRMED", "RECEIVED_IN_CASH"].includes(remote.status);

    await supabaseAdmin
      .from("billing_charges")
      .update({
        status: remote.status,
        paid_at: isPaid ? new Date().toISOString() : null,
      })
      .eq("asaas_charge_id", data.chargeId);

    if (isPaid) {
      // activate plan for 30 days
      const periodEnd = new Date();
      periodEnd.setDate(periodEnd.getDate() + 30);
      await supabaseAdmin
        .from("subscriptions")
        .update({
          status: "active",
          plan: "pro",
          current_period_start: new Date().toISOString(),
          current_period_end: periodEnd.toISOString(),
        })
        .eq("company_id", data.companyId);
    }

    return { ok: true, status: remote.status, paid: isPaid };
  });
