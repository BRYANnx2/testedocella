import { createContext, useContext, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./auth-context";

export interface Company {
  id: string;
  name: string;
  slug: string;
  logo_url: string | null;
  currency: string;
  default_margin: number;
  owner_id: string;
}

interface CompanyContextValue {
  company: Company | null;
  loading: boolean;
  refetch: () => void;
}

const CompanyContext = createContext<CompanyContextValue | undefined>(undefined);

export function CompanyProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["current-company", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: members, error } = await supabase
        .from("company_members")
        .select("company_id, companies(*)")
        .eq("user_id", user!.id)
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return (members?.companies as Company | null) ?? null;
    },
  });

  return (
    <CompanyContext.Provider value={{ company: data ?? null, loading: isLoading, refetch }}>
      {children}
    </CompanyContext.Provider>
  );
}

export function useCompany() {
  const ctx = useContext(CompanyContext);
  if (!ctx) throw new Error("useCompany must be used within CompanyProvider");
  return ctx;
}
