// Utilidades WhatsApp: normaliza telefone e gera link wa.me
import { formatBRL, formatDate } from "./format";

export function normalizePhone(raw: string | null | undefined): string {
  if (!raw) return "";
  const digits = raw.replace(/\D/g, "");
  // Brasil: se tem 10 ou 11 dígitos, adiciona 55
  if (digits.length === 10 || digits.length === 11) return `55${digits}`;
  return digits;
}

export function waLink(phone: string | null | undefined, message: string): string {
  const p = normalizePhone(phone);
  const text = encodeURIComponent(message);
  return p ? `https://wa.me/${p}?text=${text}` : `https://wa.me/?text=${text}`;
}

export interface TemplateContext {
  cliente?: string;
  total?: number;
  detalhes?: string;
  data?: string | Date | null;
  sinal?: number;
  saldo?: number;
  endereco?: string;
}

export function renderTemplate(body: string, ctx: TemplateContext): string {
  return body
    .replace(/\{cliente\}/g, ctx.cliente ?? "")
    .replace(/\{total\}/g, ctx.total != null ? formatBRL(ctx.total).replace("R$", "").trim() : "")
    .replace(/\{detalhes\}/g, ctx.detalhes ?? "")
    .replace(/\{data\}/g, ctx.data ? formatDate(ctx.data) : "")
    .replace(/\{sinal\}/g, ctx.sinal != null ? formatBRL(ctx.sinal).replace("R$", "").trim() : "")
    .replace(/\{saldo\}/g, ctx.saldo != null ? formatBRL(ctx.saldo).replace("R$", "").trim() : "")
    .replace(/\{endereco\}/g, ctx.endereco ?? "");
}
