// Pricing engine: calcula custo real de uma receita e sugere preço com margem.

export interface IngredientLite {
  id: string;
  name: string;
  unit: string;
  package_size: number;
  package_cost: number;
}

export interface RecipeItemLite {
  ingredient_id: string;
  quantity: number;
  unit: string;
}

export interface RecipeCosts {
  ingredientsCost: number;
  laborCost: number;
  fixedCost: number;
  packagingCost: number;
  totalCost: number;
  costPerServing: number;
  suggestedPrice: number;
  pricePerServing: number;
  margin: number; // %
  profit: number;
}

export function costPerUnit(ing: IngredientLite): number {
  if (!ing.package_size || ing.package_size <= 0) return 0;
  return ing.package_cost / ing.package_size;
}

export function ingredientLineCost(ing: IngredientLite, quantity: number): number {
  return costPerUnit(ing) * quantity;
}

export function computeRecipe(params: {
  items: RecipeItemLite[];
  ingredients: Map<string, IngredientLite>;
  laborCost: number;
  fixedCost: number;
  packagingCost: number;
  desiredMargin: number; // %
  servings: number;
}): RecipeCosts {
  const { items, ingredients, laborCost, fixedCost, packagingCost, desiredMargin, servings } = params;
  const ingredientsCost = items.reduce((sum, it) => {
    const ing = ingredients.get(it.ingredient_id);
    if (!ing) return sum;
    return sum + ingredientLineCost(ing, it.quantity);
  }, 0);
  const totalCost = ingredientsCost + laborCost + fixedCost + packagingCost;
  // Markup based on margin over price: price = cost / (1 - margin/100)
  const m = Math.max(0, Math.min(95, desiredMargin)) / 100;
  const suggestedPrice = m < 1 ? totalCost / (1 - m) : totalCost;
  const profit = suggestedPrice - totalCost;
  const s = Math.max(1, servings);
  return {
    ingredientsCost,
    laborCost,
    fixedCost,
    packagingCost,
    totalCost,
    costPerServing: totalCost / s,
    suggestedPrice,
    pricePerServing: suggestedPrice / s,
    margin: desiredMargin,
    profit,
  };
}
