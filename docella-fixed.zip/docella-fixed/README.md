# Docella — SaaS para Confeiteiras 🍰

SaaS completo para confeiteiras que vendem no Instagram e WhatsApp. Precificação inteligente, gestão de pedidos, clientes, cardápio digital e muito mais.

## 🚀 Como rodar o projeto

### Pré-requisitos
- Node.js 20+
- Conta no [Supabase](https://supabase.com)

### Instalação

```bash
# 1. Clone o repositório
git clone https://github.com/SEU_USUARIO/docella.git
cd docella

# 2. Instale as dependências
npm install

# 3. Configure as variáveis de ambiente
cp .env.example .env
# Preencha VITE_SUPABASE_URL e VITE_SUPABASE_PUBLISHABLE_KEY com os dados do seu projeto Supabase

# 4. Execute as migrations no Supabase
# Vá em supabase.com → seu projeto → SQL Editor e execute cada arquivo em supabase/migrations/ em ordem

# 5. Inicie o servidor de desenvolvimento
npm run dev
```

### Variáveis de ambiente

Crie um arquivo `.env` na raiz:

```env
VITE_SUPABASE_URL=https://SEU_PROJETO.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Asaas (pagamentos) — opcional, para módulo de assinatura
ASAAS_API_KEY=sua_chave_api_asaas
ASAAS_BASE_URL=https://sandbox.asaas.com/api/v3
```

## 📱 PWA — Instalar no celular

O app é uma Progressive Web App (PWA). Para instalar:

- **Android**: Abra no Chrome → Menu (3 pontinhos) → "Adicionar à tela inicial"
- **iOS (Safari)**: Abrir no Safari → Compartilhar → "Adicionar à tela de início"
- **Desktop**: Ícone de instalação na barra de endereço do Chrome/Edge

## 🗃️ Estrutura

```
src/
├── routes/
│   ├── app.tsx               # Shell principal (sidebar + mobile nav)
│   ├── app.index.tsx         # Dashboard
│   ├── app.catalog.tsx       # ✨ NOVO: Cardápio digital
│   ├── app.settings.tsx      # Configurações (melhorado)
│   ├── app.orders.tsx        # Pedidos
│   ├── app.customers.tsx     # Clientes (WPP integrado)
│   ├── app.pricing/          # Módulo de precificação
│   ├── app.finance.tsx       # Financeiro
│   ├── app.whatsapp.tsx      # Templates de mensagem
│   ├── app.billing.tsx       # Assinatura (Asaas)
│   ├── c.$slug.tsx           # Cardápio público
│   ├── auth.tsx              # Login/cadastro (Google + email)
│   └── admin/               # Painel super admin
├── lib/
│   ├── whatsapp.ts           # Utilitários wa.me
│   └── ...
└── integrations/
    └── supabase/             # Cliente e tipos
```

## 🔧 Funcionalidades

### ✅ Implementadas
- **Precificação**: Modo fácil e modo avançado com ingredientes e receitas
- **Pedidos**: Pipeline completo (orçamento → entrega)
- **Clientes**: Cadastro com WhatsApp integrado (1 clique abre conversa)
- **Calendário**: Visualização de entregas
- **Financeiro**: Faturamento, lucro, ticket médio
- **Cardápio Digital**: URL pública `/c/[slug]` com carrinho e checkout
- **Cardápio Manager**: Configure visibilidade por produto
- **WhatsApp**: Templates personalizáveis por evento
- **Assinatura**: Planos Pro e Premium via Asaas (PIX, cartão, boleto)
- **Admin**: Painel super admin com métricas da plataforma
- **PWA**: Instalável em Android, iOS e desktop
- **Mobile**: Barra de navegação inferior para celular

### 🔜 Próximas
- Upload de logo e fotos de receita
- Notificações de novo pedido via WhatsApp
- Relatórios mensais em PDF

## 💳 Integração Asaas (pagamentos)

O módulo de assinatura usa a API do Asaas. Para ativar:

1. Crie conta em [asaas.com](https://asaas.com)
2. Obtenha a API Key em "Integrações"
3. Adicione ao `.env`: `ASAAS_API_KEY=sua_chave`
4. Use `https://sandbox.asaas.com` para testes

## 📲 WhatsApp — Clique para conversar

O app usa **wa.me** (redirecionamento oficial do WhatsApp) — sem API paga.

Ao clicar no ícone de WhatsApp de um cliente, o app:
1. Normaliza o telefone (adiciona código Brasil +55)
2. Abre `https://wa.me/5511999990000?text=Olá, João!`
3. Redireciona para o WhatsApp Web ou App com a mensagem pré-preenchida

Para configurar o número da sua confeitaria, vá em **Configurações**.

## 🗺️ Deploy

### Vercel (recomendado)
```bash
npm run build
# Deploy da pasta dist/ no Vercel
```

### Netlify
Conecte o repositório GitHub → deploy automático em cada push.

### Cloudflare Pages
Suportado via `wrangler.jsonc` já incluso no projeto.

---

Feito com ♥ para confeiteiras que merecem uma gestão profissional.
