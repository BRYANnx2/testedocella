
-- Add Asaas fields to subscriptions
ALTER TABLE public.subscriptions
  ADD COLUMN IF NOT EXISTS asaas_customer_id TEXT,
  ADD COLUMN IF NOT EXISTS asaas_subscription_id TEXT;

-- Billing charges table (Asaas)
CREATE TABLE IF NOT EXISTS public.billing_charges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL,
  asaas_charge_id TEXT,
  amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  billing_type TEXT NOT NULL DEFAULT 'PIX', -- PIX, CREDIT_CARD, BOLETO
  due_date DATE,
  invoice_url TEXT,
  pix_qrcode TEXT,
  pix_copypaste TEXT,
  description TEXT,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.billing_charges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Members view billing" ON public.billing_charges FOR SELECT
  USING (is_company_member(auth.uid(), company_id));
CREATE POLICY "Managers manage billing" ON public.billing_charges FOR ALL
  USING (can_manage_company(auth.uid(), company_id))
  WITH CHECK (can_manage_company(auth.uid(), company_id));

CREATE TRIGGER set_billing_updated BEFORE UPDATE ON public.billing_charges
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Claim super admin (only works if no super admin exists yet)
CREATE OR REPLACE FUNCTION public.claim_super_admin()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user UUID := auth.uid();
  v_count INT;
BEGIN
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'N\u00e3o autenticado';
  END IF;
  SELECT COUNT(*) INTO v_count FROM public.user_roles WHERE role = 'super_admin';
  IF v_count > 0 THEN
    -- already exists; only allow if current user is already super admin (idempotent)
    IF EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = v_user AND role = 'super_admin') THEN
      RETURN jsonb_build_object('ok', true, 'already', true);
    END IF;
    RAISE EXCEPTION 'J\u00e1 existe um super admin. Pe\u00e7a para ele te promover.';
  END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (v_user, 'super_admin')
    ON CONFLICT DO NOTHING;
  RETURN jsonb_build_object('ok', true, 'promoted', true);
END;
$$;

-- Promote any user (super admin only)
CREATE OR REPLACE FUNCTION public.promote_to_super_admin(_user_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_super_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Acesso negado';
  END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (_user_id, 'super_admin')
    ON CONFLICT DO NOTHING;
  RETURN jsonb_build_object('ok', true);
END;
$$;
