-- ============================================================
-- Docella — Melhorias: Cardápio Digital e Configurações
-- ============================================================

-- Garante colunas do cardápio na tabela companies
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS catalog_headline TEXT,
  ADD COLUMN IF NOT EXISTS catalog_description TEXT,
  ADD COLUMN IF NOT EXISTS whatsapp_phone TEXT,
  ADD COLUMN IF NOT EXISTS logo_url TEXT;

-- Garante colunas de catálogo nas receitas
ALTER TABLE public.recipes
  ADD COLUMN IF NOT EXISTS cover_url TEXT,
  ADD COLUMN IF NOT EXISTS public_description TEXT,
  ADD COLUMN IF NOT EXISTS show_in_catalog BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS price_override NUMERIC;

-- Índice para buscas de receitas visíveis no catálogo
CREATE INDEX IF NOT EXISTS idx_recipes_catalog 
  ON public.recipes (company_id, is_active, show_in_catalog)
  WHERE is_active = true AND show_in_catalog = true;

-- Slug único na tabela companies (caso já não exista constraint)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'companies_slug_key'
  ) THEN
    ALTER TABLE public.companies ADD CONSTRAINT companies_slug_key UNIQUE (slug);
  END IF;
END $$;

-- Atualiza a função platform_stats para ser mais robusta
CREATE OR REPLACE FUNCTION public.platform_stats()
RETURNS json
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result json;
BEGIN
  SELECT json_build_object(
    'total_companies', (SELECT COUNT(*) FROM companies),
    'total_users', (SELECT COUNT(*) FROM profiles),
    'total_orders', (SELECT COUNT(*) FROM orders),
    'total_revenue', COALESCE((SELECT SUM(total) FROM orders WHERE status != 'canceled'), 0),
    'active_subscriptions', (SELECT COUNT(*) FROM subscriptions WHERE status = 'active'),
    'paying_subscriptions', (SELECT COUNT(*) FROM subscriptions WHERE status = 'active' AND asaas_subscription_id IS NOT NULL),
    'mrr_cents', COALESCE((SELECT COUNT(*) * 4990 FROM subscriptions WHERE status = 'active'), 0),
    'companies_last_30d', (SELECT COUNT(*) FROM companies WHERE created_at >= NOW() - INTERVAL '30 days'),
    'orders_last_30d', (SELECT COUNT(*) FROM orders WHERE created_at >= NOW() - INTERVAL '30 days')
  ) INTO result;
  RETURN result;
END;
$$;

-- Garante que super_admin pode executar a função
GRANT EXECUTE ON FUNCTION public.platform_stats() TO authenticated;
