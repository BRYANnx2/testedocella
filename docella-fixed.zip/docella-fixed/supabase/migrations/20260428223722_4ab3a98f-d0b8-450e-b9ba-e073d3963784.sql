
-- AUDIT LOGS
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID,
  user_id UUID,
  table_name TEXT NOT NULL,
  record_id UUID,
  action TEXT NOT NULL, -- INSERT/UPDATE/DELETE
  old_data JSONB,
  new_data JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_company ON public.audit_logs(company_id, created_at DESC);
CREATE INDEX idx_audit_user ON public.audit_logs(user_id, created_at DESC);
CREATE INDEX idx_audit_table ON public.audit_logs(table_name, record_id);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admin views all audits"
ON public.audit_logs FOR SELECT
USING (public.is_super_admin(auth.uid()));

CREATE POLICY "Company managers view their audits"
ON public.audit_logs FOR SELECT
USING (company_id IS NOT NULL AND public.can_manage_company(auth.uid(), company_id));

-- Generic audit trigger function
CREATE OR REPLACE FUNCTION public.audit_trigger_fn()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_company_id UUID;
  v_record_id UUID;
BEGIN
  -- Try to get company_id from row
  IF TG_OP = 'DELETE' THEN
    BEGIN v_company_id := (to_jsonb(OLD)->>'company_id')::uuid; EXCEPTION WHEN OTHERS THEN v_company_id := NULL; END;
    BEGIN v_record_id := (to_jsonb(OLD)->>'id')::uuid; EXCEPTION WHEN OTHERS THEN v_record_id := NULL; END;
    INSERT INTO public.audit_logs(company_id, user_id, table_name, record_id, action, old_data)
    VALUES (v_company_id, auth.uid(), TG_TABLE_NAME, v_record_id, TG_OP, to_jsonb(OLD));
    RETURN OLD;
  ELSE
    BEGIN v_company_id := (to_jsonb(NEW)->>'company_id')::uuid; EXCEPTION WHEN OTHERS THEN v_company_id := NULL; END;
    BEGIN v_record_id := (to_jsonb(NEW)->>'id')::uuid; EXCEPTION WHEN OTHERS THEN v_record_id := NULL; END;
    INSERT INTO public.audit_logs(company_id, user_id, table_name, record_id, action, old_data, new_data)
    VALUES (v_company_id, auth.uid(), TG_TABLE_NAME, v_record_id, TG_OP,
      CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
      to_jsonb(NEW));
    RETURN NEW;
  END IF;
END;
$$;

-- Attach to critical tables
CREATE TRIGGER audit_orders AFTER INSERT OR UPDATE OR DELETE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_payments AFTER INSERT OR UPDATE OR DELETE ON public.payments
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_recipes AFTER INSERT OR UPDATE OR DELETE ON public.recipes
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_ingredients AFTER INSERT OR UPDATE OR DELETE ON public.ingredients
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_customers AFTER INSERT OR UPDATE OR DELETE ON public.customers
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_subscriptions AFTER INSERT OR UPDATE OR DELETE ON public.subscriptions
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

CREATE TRIGGER audit_user_roles AFTER INSERT OR DELETE ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn();

-- Super admin platform stats function
CREATE OR REPLACE FUNCTION public.platform_stats()
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSONB;
BEGIN
  IF NOT public.is_super_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Acesso negado';
  END IF;
  
  SELECT jsonb_build_object(
    'total_companies', (SELECT COUNT(*) FROM public.companies),
    'total_users', (SELECT COUNT(*) FROM public.profiles),
    'total_orders', (SELECT COUNT(*) FROM public.orders),
    'total_revenue', (SELECT COALESCE(SUM(total),0) FROM public.orders WHERE status NOT IN ('cancelled')),
    'active_subscriptions', (SELECT COUNT(*) FROM public.subscriptions WHERE status IN ('active','trialing')),
    'paying_subscriptions', (SELECT COUNT(*) FROM public.subscriptions WHERE status = 'active' AND plan != 'trial'),
    'mrr_cents', (SELECT COALESCE(SUM(CASE 
      WHEN plan='pro' THEN 4900 
      WHEN plan='premium' THEN 9900 
      ELSE 0 END),0) FROM public.subscriptions WHERE status = 'active'),
    'companies_last_30d', (SELECT COUNT(*) FROM public.companies WHERE created_at > now() - interval '30 days'),
    'orders_last_30d', (SELECT COUNT(*) FROM public.orders WHERE created_at > now() - interval '30 days')
  ) INTO result;
  
  RETURN result;
END;
$$;
