-- Public catalog fields
ALTER TABLE public.recipes 
  ADD COLUMN IF NOT EXISTS cover_url text,
  ADD COLUMN IF NOT EXISTS public_description text,
  ADD COLUMN IF NOT EXISTS show_in_catalog boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS price_override numeric;

-- Public source flag on orders (so we can identify orders coming from catalog)
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'manual';

-- Public catalog message on companies
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS catalog_headline text,
  ADD COLUMN IF NOT EXISTS catalog_description text,
  ADD COLUMN IF NOT EXISTS whatsapp_phone text;

-- ===== Public read policies for catalog =====
-- Anyone can read basic company info by slug (only the columns we want exposed are read by client)
CREATE POLICY "Public can view company by slug"
ON public.companies FOR SELECT
TO anon, authenticated
USING (true);

-- Wait — we already have RLS only allowing members to view. We need a SEPARATE permissive policy for anon.
-- Existing policy "Members view their companies" stays for authenticated members; anon needs its own.
-- The CREATE POLICY above conflicts with existing. Let's drop & recreate carefully:

DROP POLICY IF EXISTS "Public can view company by slug" ON public.companies;
CREATE POLICY "Anon can view company catalog basics"
ON public.companies FOR SELECT
TO anon
USING (true);

-- Anon can view active recipes that are flagged as visible in catalog
CREATE POLICY "Anon can view catalog recipes"
ON public.recipes FOR SELECT
TO anon
USING (is_active = true AND show_in_catalog = true);

-- Anon can INSERT customers (will be tied to company via the order flow)
CREATE POLICY "Anon can create customer via catalog"
ON public.customers FOR INSERT
TO anon
WITH CHECK (true);

-- Anon can INSERT orders coming from catalog
CREATE POLICY "Anon can create order via catalog"
ON public.orders FOR INSERT
TO anon
WITH CHECK (source = 'catalog');

-- Anon can INSERT order_items linked to a catalog order they just created
CREATE POLICY "Anon can create order_items via catalog"
ON public.order_items FOR INSERT
TO anon
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders o
    WHERE o.id = order_items.order_id AND o.source = 'catalog'
  )
);

-- Index for slug lookups
CREATE INDEX IF NOT EXISTS idx_companies_slug ON public.companies(slug);
CREATE INDEX IF NOT EXISTS idx_recipes_company_catalog ON public.recipes(company_id) WHERE is_active = true AND show_in_catalog = true;