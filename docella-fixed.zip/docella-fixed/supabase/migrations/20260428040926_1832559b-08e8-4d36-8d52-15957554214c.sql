
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('super_admin', 'owner', 'admin', 'member');
CREATE TYPE public.subscription_status AS ENUM ('trialing', 'active', 'past_due', 'canceled', 'incomplete');
CREATE TYPE public.order_status AS ENUM ('quote_sent', 'awaiting_confirmation', 'confirmed', 'in_production', 'ready', 'delivered', 'finalized', 'canceled');
CREATE TYPE public.payment_status AS ENUM ('pending', 'partial', 'paid', 'refunded');
CREATE TYPE public.payment_method AS ENUM ('pix', 'cash', 'card', 'transfer', 'other');
CREATE TYPE public.invite_status AS ENUM ('pending', 'accepted', 'revoked', 'expired');

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  avatar_url TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============ COMPANIES ============
CREATE TABLE public.companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  logo_url TEXT,
  currency TEXT NOT NULL DEFAULT 'BRL',
  timezone TEXT NOT NULL DEFAULT 'America/Sao_Paulo',
  default_margin NUMERIC(5,2) NOT NULL DEFAULT 60,
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

-- ============ COMPANY MEMBERS ============
CREATE TABLE public.company_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, user_id)
);
ALTER TABLE public.company_members ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_company_members_user ON public.company_members(user_id);
CREATE INDEX idx_company_members_company ON public.company_members(company_id);

-- ============ USER ROLES ============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  company_id UUID REFERENCES public.companies(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, company_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_user_roles_user ON public.user_roles(user_id);

-- ============ SECURITY DEFINER FUNCTIONS ============
CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = 'super_admin');
$$;

CREATE OR REPLACE FUNCTION public.is_company_member(_user_id UUID, _company_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.company_members WHERE user_id = _user_id AND company_id = _company_id
  ) OR public.is_super_admin(_user_id);
$$;

CREATE OR REPLACE FUNCTION public.has_company_role(_user_id UUID, _company_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND company_id = _company_id AND role = _role
  ) OR public.is_super_admin(_user_id);
$$;

CREATE OR REPLACE FUNCTION public.can_manage_company(_user_id UUID, _company_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND company_id = _company_id AND role IN ('owner','admin')
  ) OR public.is_super_admin(_user_id);
$$;

CREATE OR REPLACE FUNCTION public.get_user_company_ids(_user_id UUID)
RETURNS SETOF UUID LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT company_id FROM public.company_members WHERE user_id = _user_id;
$$;

-- ============ PROFILES POLICIES ============
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id OR public.is_super_admin(auth.uid()));
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- ============ COMPANIES POLICIES ============
CREATE POLICY "Members view their companies" ON public.companies FOR SELECT USING (public.is_company_member(auth.uid(), id));
CREATE POLICY "Authenticated users create companies" ON public.companies FOR INSERT WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "Owners/admins update company" ON public.companies FOR UPDATE USING (public.can_manage_company(auth.uid(), id));
CREATE POLICY "Owners delete company" ON public.companies FOR DELETE USING (public.has_company_role(auth.uid(), id, 'owner'));

-- ============ COMPANY MEMBERS POLICIES ============
CREATE POLICY "Members view own memberships" ON public.company_members FOR SELECT USING (user_id = auth.uid() OR public.can_manage_company(auth.uid(), company_id));
CREATE POLICY "Managers add members" ON public.company_members FOR INSERT WITH CHECK (public.can_manage_company(auth.uid(), company_id) OR user_id = auth.uid());
CREATE POLICY "Managers remove members" ON public.company_members FOR DELETE USING (public.can_manage_company(auth.uid(), company_id));

-- ============ USER ROLES POLICIES ============
CREATE POLICY "Users view own roles" ON public.user_roles FOR SELECT USING (user_id = auth.uid() OR (company_id IS NOT NULL AND public.can_manage_company(auth.uid(), company_id)));
CREATE POLICY "Managers assign roles" ON public.user_roles FOR INSERT WITH CHECK (public.can_manage_company(auth.uid(), company_id) OR (user_id = auth.uid() AND role = 'owner'));
CREATE POLICY "Managers revoke roles" ON public.user_roles FOR DELETE USING (public.can_manage_company(auth.uid(), company_id));

-- ============ CUSTOMERS ============
CREATE TABLE public.customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  address TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_customers_company ON public.customers(company_id);
CREATE POLICY "Members view customers" ON public.customers FOR SELECT USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members create customers" ON public.customers FOR INSERT WITH CHECK (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members update customers" ON public.customers FOR UPDATE USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Managers delete customers" ON public.customers FOR DELETE USING (public.can_manage_company(auth.uid(), company_id));

-- ============ INGREDIENTS ============
CREATE TABLE public.ingredients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT 'g',
  package_size NUMERIC(12,3) NOT NULL DEFAULT 1000,
  package_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  supplier TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.ingredients ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_ingredients_company ON public.ingredients(company_id);
CREATE POLICY "Members view ingredients" ON public.ingredients FOR SELECT USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members create ingredients" ON public.ingredients FOR INSERT WITH CHECK (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members update ingredients" ON public.ingredients FOR UPDATE USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members delete ingredients" ON public.ingredients FOR DELETE USING (public.is_company_member(auth.uid(), company_id));

-- ============ RECIPES (products) ============
CREATE TABLE public.recipes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  yield_qty NUMERIC(12,3) NOT NULL DEFAULT 1,
  yield_unit TEXT NOT NULL DEFAULT 'un',
  servings INTEGER NOT NULL DEFAULT 1,
  labor_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  fixed_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  packaging_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  desired_margin NUMERIC(5,2) NOT NULL DEFAULT 60,
  suggested_price NUMERIC(12,2),
  image_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.recipes ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_recipes_company ON public.recipes(company_id);
CREATE POLICY "Members view recipes" ON public.recipes FOR SELECT USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members create recipes" ON public.recipes FOR INSERT WITH CHECK (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members update recipes" ON public.recipes FOR UPDATE USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members delete recipes" ON public.recipes FOR DELETE USING (public.is_company_member(auth.uid(), company_id));

-- ============ RECIPE ITEMS ============
CREATE TABLE public.recipe_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id UUID NOT NULL REFERENCES public.recipes(id) ON DELETE CASCADE,
  ingredient_id UUID NOT NULL REFERENCES public.ingredients(id) ON DELETE RESTRICT,
  quantity NUMERIC(12,3) NOT NULL,
  unit TEXT NOT NULL DEFAULT 'g',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.recipe_items ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_recipe_items_recipe ON public.recipe_items(recipe_id);
CREATE POLICY "Members view recipe_items" ON public.recipe_items FOR SELECT USING (EXISTS (SELECT 1 FROM public.recipes r WHERE r.id = recipe_id AND public.is_company_member(auth.uid(), r.company_id)));
CREATE POLICY "Members manage recipe_items" ON public.recipe_items FOR ALL USING (EXISTS (SELECT 1 FROM public.recipes r WHERE r.id = recipe_id AND public.is_company_member(auth.uid(), r.company_id))) WITH CHECK (EXISTS (SELECT 1 FROM public.recipes r WHERE r.id = recipe_id AND public.is_company_member(auth.uid(), r.company_id)));

-- ============ ORDERS ============
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES public.customers(id) ON DELETE SET NULL,
  order_number SERIAL,
  status public.order_status NOT NULL DEFAULT 'quote_sent',
  payment_status public.payment_status NOT NULL DEFAULT 'pending',
  delivery_date DATE,
  delivery_time TIME,
  delivery_address TEXT,
  subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total NUMERIC(12,2) NOT NULL DEFAULT 0,
  deposit NUMERIC(12,2) NOT NULL DEFAULT 0,
  paid_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  notes TEXT,
  internal_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_orders_company ON public.orders(company_id);
CREATE INDEX idx_orders_customer ON public.orders(customer_id);
CREATE INDEX idx_orders_delivery_date ON public.orders(delivery_date);
CREATE POLICY "Members view orders" ON public.orders FOR SELECT USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members create orders" ON public.orders FOR INSERT WITH CHECK (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Members update orders" ON public.orders FOR UPDATE USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Managers delete orders" ON public.orders FOR DELETE USING (public.can_manage_company(auth.uid(), company_id));

-- ============ ORDER ITEMS ============
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  recipe_id UUID REFERENCES public.recipes(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  quantity NUMERIC(12,3) NOT NULL DEFAULT 1,
  unit_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  unit_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  total NUMERIC(12,2) NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_order_items_order ON public.order_items(order_id);
CREATE POLICY "Members view order_items" ON public.order_items FOR SELECT USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND public.is_company_member(auth.uid(), o.company_id)));
CREATE POLICY "Members manage order_items" ON public.order_items FOR ALL USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND public.is_company_member(auth.uid(), o.company_id))) WITH CHECK (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND public.is_company_member(auth.uid(), o.company_id)));

-- ============ PAYMENTS ============
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  method public.payment_method NOT NULL DEFAULT 'pix',
  paid_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_payments_order ON public.payments(order_id);
CREATE POLICY "Members view payments" ON public.payments FOR SELECT USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND public.is_company_member(auth.uid(), o.company_id)));
CREATE POLICY "Members manage payments" ON public.payments FOR ALL USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND public.is_company_member(auth.uid(), o.company_id))) WITH CHECK (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND public.is_company_member(auth.uid(), o.company_id)));

-- ============ WHATSAPP TEMPLATES ============
CREATE TABLE public.whatsapp_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  trigger TEXT NOT NULL,
  name TEXT NOT NULL,
  body TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.whatsapp_templates ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_wa_templates_company ON public.whatsapp_templates(company_id);
CREATE POLICY "Members view wa_templates" ON public.whatsapp_templates FOR SELECT USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Managers manage wa_templates" ON public.whatsapp_templates FOR ALL USING (public.can_manage_company(auth.uid(), company_id)) WITH CHECK (public.can_manage_company(auth.uid(), company_id));

-- ============ SUBSCRIPTIONS ============
CREATE TABLE public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL UNIQUE REFERENCES public.companies(id) ON DELETE CASCADE,
  plan TEXT NOT NULL DEFAULT 'trial',
  status public.subscription_status NOT NULL DEFAULT 'trialing',
  current_period_start TIMESTAMPTZ NOT NULL DEFAULT now(),
  current_period_end TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '14 days'),
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view subscription" ON public.subscriptions FOR SELECT USING (public.is_company_member(auth.uid(), company_id));
CREATE POLICY "Managers manage subscription" ON public.subscriptions FOR ALL USING (public.can_manage_company(auth.uid(), company_id)) WITH CHECK (public.can_manage_company(auth.uid(), company_id));

-- ============ UPDATED_AT TRIGGERS ============
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_companies_updated BEFORE UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_customers_updated BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_ingredients_updated BEFORE UPDATE ON public.ingredients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_recipes_updated BEFORE UPDATE ON public.recipes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_orders_updated BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_wa_updated BEFORE UPDATE ON public.whatsapp_templates FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_subs_updated BEFORE UPDATE ON public.subscriptions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ HANDLE NEW USER TRIGGER ============
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)),
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ HANDLE NEW COMPANY TRIGGER ============
CREATE OR REPLACE FUNCTION public.handle_new_company()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.company_members (company_id, user_id) VALUES (NEW.id, NEW.owner_id) ON CONFLICT DO NOTHING;
  INSERT INTO public.user_roles (user_id, company_id, role) VALUES (NEW.owner_id, NEW.id, 'owner') ON CONFLICT DO NOTHING;
  INSERT INTO public.subscriptions (company_id, plan, status) VALUES (NEW.id, 'trial', 'trialing') ON CONFLICT DO NOTHING;
  -- Default WhatsApp templates
  INSERT INTO public.whatsapp_templates (company_id, trigger, name, body) VALUES
    (NEW.id, 'quote', 'Envio de orçamento', 'Olá {cliente}! 🍰 Segue o orçamento do seu pedido: {detalhes}. Total: R$ {total}. Posso confirmar?'),
    (NEW.id, 'confirmation', 'Confirmação de pedido', 'Oba! Seu pedido foi confirmado ✨ Entrega em {data}. Sinal: R$ {sinal}.'),
    (NEW.id, 'payment_reminder', 'Lembrete de pagamento', 'Oi {cliente}! Passando para lembrar do saldo de R$ {saldo} referente ao seu pedido 💛'),
    (NEW.id, 'delivery_reminder', 'Lembrete de entrega', 'Tudo pronto! Seu pedido será entregue amanhã ({data}) no endereço {endereco} 🎉'),
    (NEW.id, 'review_request', 'Pedido de avaliação', 'Oi {cliente}! Espero que tenha amado 💖 Se puder, me manda uma fotinho e sua avaliação, vai me ajudar muito!');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_company_created AFTER INSERT ON public.companies FOR EACH ROW EXECUTE FUNCTION public.handle_new_company();
